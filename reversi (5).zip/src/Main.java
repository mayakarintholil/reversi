import controller.ControllerFeatures;
import controller.ReversiController;
import model.HumanPlayer;
import model.IReversi;
import model.Player;
import model.ReversiModel;
import view.ReversiFrame;
import view.ReversiView;



/**
 * Driver for a game of Reversi.
 */
public class Main {

  /**
   * The main entry point of the Reversi game.
   *
   * @param args the command-line arguments passed to the program (not used in this method).
   */
  public static void main(String[] args) {
    //type of player, then type of strategy, only 2 args allowed

    IReversi model = new ReversiModel();

    ReversiView view1 = new ReversiFrame(model);
    ReversiView view2 = new ReversiFrame(model);
    Player player1 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER1);
    Player player2 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER2);
    ControllerFeatures controller1 = new ReversiController(model, view1, player1);
    ControllerFeatures controller2 = new ReversiController(model, view2, player2);
    view1.makeVisible();
    view2.makeVisible();
    model.startGame();

    /*
    for (String s : args) {
      if (Integer.parseInt(s) < 0) {
        throw new IndexOutOfBoundsException();
      }
      if (args.length > 2) {
        throw new IllegalStateException();
      }
    }
    switch (args[0]) {
      case "human":
        Player player1 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER1);
        break;
      case "AI":
        Player player1 = new MachinePlayer(model, ReversiModel.PlayerType.PLAYER1);
        break;

    }

    switch (args[1]) {
      case "strat1":
        ReversiStrategy strategy = new CaptureMostOnThisTurn();
        break;
    }





  }

     */
  }
}