package controller;

import model.Coordinate;
import model.IReversi;
import model.ModelFeatures;
import model.Player;
import view.ReversiView;

/**
 * Controller for the game of Reversi. Acts as a listener for player actions and notifications of
 * whether it is this player's turn. The controller is connected to the model and view of the
 * game, simultaneously updating the game state and calling on the view to update its frame
 * according to player actions and turn notifications.
 */
public class ReversiController implements ControllerFeatures, ModelFeatures {

  private IReversi model;
  private ReversiView view;
  private final Player player;


  /**
   * Constructs a controller for a game of Reversi.
   * @param model the model of the game to control and update
   * @param view the view to get user input from
   * @param player the player this controller represents
   */
  public ReversiController(IReversi model, ReversiView view, Player player) {
    this.model = model;
    this.view = view;
    this.player = player;
    view.addFeatures(this);
  }

  //  @Override
  //  public void selectCell() {
  //    view.selectCell();
  //  }

  @Override
  public void makeMove() { //what to do with controller here
    //TODO: Fix copy constructor for Board!!
    Coordinate playerChosenCoord = player.getMeMyNextMove();
    if (playerChosenCoord.getQ() == -1) { //player is human so make move on view's selected cell
      Coordinate coordToMove = view.getSelectedCellToMoveOn();
      System.out.print(coordToMove.getQ());
      System.out.print(coordToMove.getR());
      System.out.print("Got here");
      model.completeMove(model.getGameBoard().getCells()[coordToMove.getQ()][coordToMove.getR()]);

      view.refresh();
    }
    else { //player is AI so make move on strategy coord
      System.out.print(playerChosenCoord.getQ());
      System.out.print(playerChosenCoord.getR());
      model.completeMove(model.getGameBoard().getCells()[playerChosenCoord.getQ()]
              [playerChosenCoord.getR()]);

      view.refresh();
    }
    //    try {
    //      model.completeMove(model.getGameBoard().getCells()[playerChosenCoord.getQ()]
    //              [playerChosenCoord.getR()]);
    //      //view.makeMove();
    //    } catch (IllegalArgumentException exception) {
    //      view.displayErrorMsg();
    //    }

    //this doesn't need to know what cell to move because IT IS JUST FLIPPING
    // ALL OF THIS PLAYERS CELLS TO ITS STATE ON THE BOARD :))))))
    //TODO: actually put the code of placing a circle in the view's move method.
    //TODO: try catch both illegal arg exceptions in here and call view to DISPLAY THE NEW
    // MESSAGE SAYING "Illegal move for Player ..."
  }

  @Override
  public void passOnTurn() {
    model.passMove();
    //TODO: call the it's my turn notification from other interface to print message in view
    view.passOnTurn(); //do nothing, but put the text message of the next players turn
    // notification in the panel/frame
  }

  @Override
  public void exitProgram() {
    System.exit(0);
  }

  //controller acting as a listener to both features
  @Override
  public void notifyWhichPlayersTurn() {
    if (model.getCurrentPlayer().equals(player.getPlayerType())) {
      player.getMeMyNextMove();
    }
    //has to notify the player if it is their turn or not . HOW?
  }


  /**
   * Refreshes the view from controller call every time a move is made. 
   */
  @Override
  public void refreshView() {
    this.view.refresh();
  }
}
