package model;


/**
 * Represents a Human player in the game of Reversi. Can make legal moves and win the game.
 */
public class HumanPlayer implements Player {

  //cannot be final because model updates after each move
  private IReversi model;
  private final ReversiModel.PlayerType type;


  public HumanPlayer(IReversi model, ReversiModel.PlayerType type) {
    this.model = model;
    this.type = type;
  }

  //TODO: How to use the copy of board to get the entered cell by user
  //view calls on controller, controller calls on the player to get preferred move and then calls
  // on the model to make the move, player gets the cell
  @Override
  public Coordinate getMeMyNextMove() {
    //do nothing here
    this.model.getGameBoard();
    return new Coordinate(-1, -1);

  }

  @Override
  public ReversiModel.PlayerType getPlayerType() {
    return this.type;
  }


}
