package model;

import strategies.CaptureMostOnThisTurn;
import strategies.ReversiStrategy;

/**
 * Represents a computer player in a game of Reversi. The computer player uses a strategy to best
 * determine where to make their next move.
 */
public class MachinePlayer implements Player {

  //players only have one strategy that can be used so it is final
  private final ReversiStrategy strategy;

  //cannot be final because model updates after each move 
  private IReversi model;

  private final ReversiModel.PlayerType type;


  /**
   * Constructs a computer player for a game of Reversi.
   * @param model the model to associate this player with
   * @param type whether this player is Player 1 or Player 2 in the game
   */
  public MachinePlayer(IReversi model, ReversiModel.PlayerType type) {
    this.model = model;
    this.type = type;
    this.strategy = new CaptureMostOnThisTurn();
    //make machine player always player 2?
    // this.player2 = this;
  }

  @Override
  public Coordinate getMeMyNextMove() {
    //every move is determined by the strategy, which fortunately returns a coordinate
    //returns the best place to make a move on each time.
    return strategy.chooseMove(model, this.type);
  }

  @Override
  public ReversiModel.PlayerType getPlayerType() {
    return this.type;
  }
}
