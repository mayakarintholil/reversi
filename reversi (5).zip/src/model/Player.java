package model;

//player can be either a human player or a computer player

/**
 * Represents an interface for a player in a game of Reversi. This player can be Human or a Computer
 * player.
 */
public interface Player {
  //A Player can be Human or AI 
  
  /* Methods needed for a Player: 
      1. Make a move: A player should have the ability to make a move on the cell they desire
      that is within the bounds of the board.
      void makeMove(IReversi model);

      2. Pass on turn: If Player has no legal moves left, they must have the ability to pass on
      their turn in the game.
      void passMyTurn(IReversi model);

      3. Determine if there are any more legal moves left in this game: A Player may want to have
       the ability of knowing how many legal moves are left for them on the board in this game.
       This may give them more ability to strategize and choose moves wisely.
      boolean anyMoreMovesLeftOnBoard(IReversi model);

      4. Determine who won the game: A Player will need to know who the winner of the game is
       at the end of the game.
      Player whoWonThisGame(IReversi model, Player other);

      5. Determine if the game is over: A Player will need to know if the game is over due to no
      more legal moves, two passes consecutively or someone has won, or whether they need to
      keep playing.
      boolean isThisGameOver(IReversi model);

      6. Determine what this Player's score is: A Player will want to keep track of what their
      score is throughout the game.
      int getMyScore(IReversi model);

      7. Determine if it is this Player's turn: Since this player cannot make a move unless it is
       their turn, they might want to know if it is their turn to make a move or the opposite
       player's.
      boolean isItMyTurn(IReversi model);

      8. Determine if this Player can play at a specific cell: A Player might want to know if it
      is legal for them to play a move at a specific cell in the board, given the cell's location
       and state.
       boolean canIPlayOnThisCell(Cell cell, IReversiModel);
      
   */

  /**
   * Returns the best coordinate to make a move on for a Player. For human players, the next move
   * is determined by what cell is clicked in the view, while for machine players, the next move
   * is chosen by a strategy and returned.
   * @return the Coordinate to make the next move for
   */
  Coordinate getMeMyNextMove();


  /**
   * Returns whether this Player is Player 1 or PLayer 2 in the game of Reversi, according to the
   * model.
   * @return PlayerType, which player this Player is
   */
  ReversiModel.PlayerType getPlayerType();

}
