package model;

import java.util.List;
import java.util.ArrayList;
import java.awt.Color;


/**
 * Represents a game of Reversi between two players on a hexagonal shaped board.
 */
public class ReversiModel implements IReversi {

  //2d array of cells - size of the board will stay the same
  //do we make a square and make outside of hex invisible
  //maybe use axial coordinates so u would only need q and r
  private final Board gameBoard;

  /**
   * Represents two players playing a game of Reversi. Players have colors associated with them.
   */
  public enum PlayerType {
    PLAYER1,
    PLAYER2
  }

  private final int boardSize;
  private final RuleKeepers rulebook;
  private PlayerType currentPlayer;
  private boolean player1Passed;
  private boolean player2Passed;
  private boolean did2PlayersPassCon;
  private boolean hasGameBeenStarted;


  /**
   * Default constructor between 2 human players with a default board size of 7.
   */
  //default constructor between 2 human players with a default board size of 7
  public ReversiModel() {
    this.boardSize = 7;
    this.gameBoard = new Board(boardSize);
    this.rulebook = new RuleKeepers();
    this.currentPlayer = PlayerType.PLAYER2;
    this.player1Passed = false;
    this.player2Passed = false;
    this.did2PlayersPassCon = false;
    hasGameBeenStarted = false;

    //set starting game board
    this.setStartingCellsOfBoard();
  }

  /**
   * Represents the copy constructor for making a copy of a model of Reversi.
   * @param other the model to make a copy of
   */
  public ReversiModel(ReversiModel other) {
    this.boardSize = other.boardSize;
    this.gameBoard = new Board(other.getBoardSize());
    this.currentPlayer = other.currentPlayer;
    this.did2PlayersPassCon = other.did2PlayersPassCon;
    this.rulebook = new RuleKeepers();
    this.player1Passed = other.player1Passed;
    this.player2Passed = other.player2Passed;
    this.hasGameBeenStarted = false;
  }

  /**
   * Constructor between 2 human players with a users preferred size. The size passed in
   * must be odd, even sizes are not allowed.
   * @param boardSize the preferred size to make hexagonal board with
   * @throws IllegalArgumentException exception thrown if boardSize is even
   */
  //default constructor between 2 human players with a users preferred size
  public ReversiModel(int boardSize) {

    this.boardSize = boardSize;
    this.gameBoard = new Board(this.boardSize);
    this.rulebook = new RuleKeepers();
    this.currentPlayer = PlayerType.PLAYER2;
    rulebook.cannotMakeBoardNegOrEvenInputOnModel(this);
    this.player1Passed = false;
    this.player2Passed = false;
    this.did2PlayersPassCon = false;
    this.hasGameBeenStarted = false;
    //set starting game board
    this.setStartingCellsOfBoard();

  }

  /**
   * Sets the starting cells of the board in the game. The neighboring six cells of the center
   * cell alternate in Player colors. For example, each neighboring cell alternates with the colors
   * black and white.
   */
  private void setStartingCellsOfBoard() {
    try {
      //get center cell of board and set all neighbors to alternating players
      Cell centerCell = this.gameBoard.getCells()
              [(int) Math.floor(this.boardSize / 2.0)][(int) Math.floor(this.boardSize / 2.0)];

      //get each neighbor
      Cell topRightCell = this.getRelativeCell(centerCell, 1, -1);
      Cell rightCell = this.getRelativeCell(centerCell, 1, 0);
      Cell bottomRightCell = this.getRelativeCell(centerCell, 0, 1);
      Cell bottomLeftCell = this.getRelativeCell(centerCell, -1, 1);
      Cell leftCell = this.getRelativeCell(centerCell, -1, 0);
      Cell topLeftCell = this.getRelativeCell(centerCell, 0, -1);

      topRightCell.fillMyCell(Color.WHITE);
      rightCell.fillMyCell(Color.BLACK);
      bottomRightCell.fillMyCell(Color.WHITE);
      bottomLeftCell.fillMyCell(Color.BLACK);
      leftCell.fillMyCell(Color.WHITE);
      topLeftCell.fillMyCell(Color.BLACK);
    } catch (IllegalStateException illegalStateException) {
      //do nothing
    }
    
  }

  public void startGame() {
    hasGameBeenStarted = true;
  }


  
  //ABSTRACTED METHOD FOR GETTING NEIGHBORING CELLS OF CENTER CELL
  
  private Cell getRelativeCell(Cell centerCell, int qOffset, int rOffset) {
    if (!hasGameBeenStarted) {
      throw new IllegalStateException("game hasn't been started");
    }
    int qCoord = centerCell.getQCoord() + qOffset;
    int rCoord = centerCell.getRCoord() + rOffset;
    return this.gameBoard.getCells()[qCoord][rCoord];
  }

  /**
   * Gets the current player that whose turn it is on.
   * @return the currentPlayer, either Player 1 or Player 2.
   */
  @Override
  public PlayerType getCurrentPlayer() {
    return currentPlayer;
  }

  /**
   * Returns the game board which allows user to see it in the current game of Reversi.
   * @return the Board associated with the game
   */
  @Override
  public Board getGameBoard() {
    return this.gameBoard;
  }

  /**
   * Allows the user to get the size of the board they are playing the game with.
   * @return the board's size
   */
  public int getBoardSize() {
    return this.boardSize;
  }

  /**
   * Returns a copy of the cell at the given cell coordinates to the user, including the cell's
   * color.
   * @param q the user's desired q coordinate
   * @param r the user's desired r coordinate
   * @return a Cell with its contents
   */
  public Cell getCellContentsAt(int q, int r) {
    if (!hasGameBeenStarted) {
      throw new IllegalStateException("game hasn't been started");
    }
    if (this.gameBoard.getCells()[q][r] == null) {
      throw new IllegalArgumentException("Null cells don't have contents.");
    } else if (q >= this.boardSize || r >= this.boardSize) {
      throw new IllegalArgumentException("Can't get contents of a cell out of bounds.");
    }
    return new Cell(this.gameBoard.getCells()[q][r].getStateOfCell(), new Coordinate(q, r));
  }


  /**
   * Determines if a user can play on the coordinate given. In order for it to be playable,
   * it must be in bounds, not null, and empty.
   * @param coord the coordinate to make a move on
   * @return true or false
   */
  public boolean canThisCellBePlayedOn(Coordinate coord) {
    if (!hasGameBeenStarted) {
      throw new IllegalStateException("game hasn't been started");
    }
    Cell cellToPlayOn = this.gameBoard.getCells()[coord.getQ()][coord.getR()];
    if (cellExistsInBoard(this.gameBoard.getCells(), coord.getQ(), coord.getR())
            && cellToPlayOn.getStateOfCell().
            equals(Cell.CellState.EMPTY)) {
      return this.doesMyCellHaveAnyFlippablePaths(cellToPlayOn);
    } else {
      return false;
    }
  }

  /**
   * Checks if the current player has any legal moves left in the game. Does this by looking
   * through all empty cells in the board and if any paths of those cells can be flipped in favor
   * of this current player.
   * @return true or false
   */
  public boolean doesCurrentPlayerHaveAnyLegalMoves() {
    if (!hasGameBeenStarted) {
      throw new IllegalStateException("game hasn't been started");
    }
    List<Cell> emptyCellsInBoard = new ArrayList<>();
    for (int row = 0; row < boardSize; row++) {
      for (int col = 0; col < boardSize; col++) {
        if (this.gameBoard.getCells()[col][row] == null) {
          break;
        }
        if (this.gameBoard.getCells()[col][row].getStateOfCell().equals(Cell.CellState.EMPTY)) {
          emptyCellsInBoard.add(this.gameBoard.getCells()[col][row]);
        }
      }
    }
    int countOfPlayableCells = 0;
    for (Cell emptyCell : emptyCellsInBoard) {
      if (this.canThisCellBePlayedOn(emptyCell.getCellsCoordinate())) {
        countOfPlayableCells++;
      }
    }
    return countOfPlayableCells > 0;

  }

  /**
   * Returns the given player's score. The score for a player is determined by the total number
   * of cells in the board filled with that player's color.
   * @param playerWhosScoreWeWant - the player who's score we are looking for currently.
   * @return the number of cells filled with the current player 
   */
  public int getCurrentPlayerScore(PlayerType playerWhosScoreWeWant) {
    if (!hasGameBeenStarted) {
      throw new IllegalStateException("game hasn't been started");
    }
    int player1Filled = 0;
    int player2Filled = 0;

    for (int row = 0; row < boardSize; row++) {
      for (int col = 0; col < boardSize; col++) {
        if (this.gameBoard.getCells()[col][row] == null) {
          break;
        }
        if (this.gameBoard.getCells()[col][row].getStateOfCell()
                .equals(Cell.CellState.WHITEFILLED)) {
          player1Filled++;
        }
        else if (this.gameBoard.getCells()[col][row].getStateOfCell()
                .equals(Cell.CellState.BLACKFILLED)) {
          player2Filled++;
        }
      }
    }

    if (playerWhosScoreWeWant.equals(PlayerType.PLAYER1)) {
      return player1Filled;
    } else {
      return player2Filled;
    }

  }


  //game over : boolean value
  /**
   * Determines whether the current game is over. If two players pass in a row, or if there
   * are no more valid moves to be made, then the game is over.
   * @return true if game is over, false if not
   */
  @Override
  public boolean isGameOver() {
    if (!hasGameBeenStarted) {
      throw new IllegalStateException("game hasn't been started");
    }
    //if two players pass in a row
    return this.didTwoPlayersPass();
  }


  /**
   * Gets the winner of the game after the game is over. The winner is determined by the player
   * that has filled more cells in the board. If both players fill an equal number of cells, then
   * the game is a tie.
   * @return the Player that won the game, or null if the game is tied
   */
  @Override
  public PlayerType getWinner() {
    if (!hasGameBeenStarted) {
      throw new IllegalStateException("game hasn't been started");
    }
    PlayerType winningPlayer = PlayerType.PLAYER1;
    int countOfWhitePieces = 0;
    int countOfBlackPieces = 0;
    //go through the list of cells, and for each with a black color add to
    // count of black, for each with a white color add to white count,
    //which ever is higher wins
    for (int row = 0; row < this.gameBoard.getCells().length; row++) {
      for (int col = 0; col < this.gameBoard.getCells().length; col++) {
        if (this.gameBoard.getCells()[col][row] == null
                || this.gameBoard.getCells()[col][row].getStateOfCell()
                .equals(Cell.CellState.EMPTY)) {
          break;
        }
        if (this.gameBoard.getCells()[col][row].getStateOfCell()
                .equals(Cell.CellState.BLACKFILLED)) {
          countOfBlackPieces++;
        }
        if (this.gameBoard.getCells()[col][row].getStateOfCell()
                .equals(Cell.CellState.WHITEFILLED)) {
          countOfWhitePieces++;
        }
      }
    }
    //have to look what to do if they tie.
    if (countOfWhitePieces > countOfBlackPieces) {
      winningPlayer =  PlayerType.PLAYER1;
    }
    else if (countOfBlackPieces > countOfWhitePieces) {
      winningPlayer =  PlayerType.PLAYER2;
    }
    return winningPlayer;
  }

  /**
   * Allows a player to select a legal empty cell and play a disc in that cell. A play is legal for
   * Player 1 if the disc being played is adjacent (in at least one direction) to a straight line
   * of the opponent Player 2's discs, at the far end of which is another player 1 disc.
   * The result of a legal move is that all of player 2’s discs in all directions that
   * are sandwiched between two discs of player 1 get flipped to player 1. Then the current
   * player switches to Player 2.
   * @param chosenCell the cell to make a move on
   * @throws IllegalStateException if a move is tried to be made after the game is over
   * @throws IllegalArgumentException if the given cell to move on is not empty
   */
  @Override
  public void completeMove(Cell chosenCell) {
    if (!hasGameBeenStarted) {
      throw new IllegalStateException("game hasn't been started");
    }
    rulebook.chosenCellForMoveMustBeEmpty(chosenCell);
    if (this.did2PlayersPassCon) {
      throw new IllegalStateException("cannot play after game is over");
    }
 
    else {
      //if (chosenCell.getStateOfCell().equals(Cell.CellState.EMPTY)) {

      //if (this.cellsToFlipTopRight(chosenCell).isEmpty()
      //  && this.cellsToFlipStraightRight(chosenCell).isEmpty()
      //        && this.cellsToFlipBottomRight(chosenCell).isEmpty()
      //        && this.cellsToFlipBottomLeft(chosenCell).isEmpty()
      //        && this.cellsToFlipStraightLeft(chosenCell).isEmpty()
      //        && this.cellsToFlipTopLeft(chosenCell).isEmpty()) {
      //  switchTurns(); // basically pass
      //}
      if (!this.cellsToFlipTopRight(chosenCell).isEmpty()) {
        this.flipPathOfNeighbors(this.cellsToFlipTopRight(chosenCell));
      }
      if (!this.cellsToFlipStraightRight(chosenCell).isEmpty()) {
        this.flipPathOfNeighbors(this.cellsToFlipStraightRight(chosenCell));
      }
      if (!this.cellsToFlipBottomRight(chosenCell).isEmpty()) {
        this.flipPathOfNeighbors(this.cellsToFlipBottomRight(chosenCell));
      }
      if (!this.cellsToFlipBottomLeft(chosenCell).isEmpty()) {
        this.flipPathOfNeighbors(this.cellsToFlipBottomLeft(chosenCell));
      }
      if (!this.cellsToFlipStraightLeft(chosenCell).isEmpty()) {
        this.flipPathOfNeighbors(this.cellsToFlipStraightLeft(chosenCell));
      }
      if (!this.cellsToFlipTopLeft(chosenCell).isEmpty()) {
        this.flipPathOfNeighbors(this.cellsToFlipTopLeft(chosenCell));
      }

      //rulebook.currentPlayerMustBePlayer1OrPlayer2(this, player1, player2);

      //fills the chosen cell to the players color after flipping
      // the cells in its neighboring rows
      if (this.currentPlayer.equals(PlayerType.PLAYER1)) {
        chosenCell.fillMyCell(Color.WHITE);
      } else if (this.currentPlayer.equals(PlayerType.PLAYER2)) {
        chosenCell.fillMyCell(Color.BLACK);
      } // if they make the move, switch the turn at the end

    }

    if (currentPlayer.equals(PlayerType.PLAYER1)) {
      player1Passed = false;
    } else {
      player2Passed = false;
    }
    this.switchTurns();

  }

  /**
   * Returns whether the given cell has any paths that can be flipped to the current player's
   * color.
   * @param chosenCell the cell to check flippable paths for
   * @return true or false
   */
  private boolean doesMyCellHaveAnyFlippablePaths(Cell chosenCell) {
    return !this.cellsToFlipTopRight(chosenCell).isEmpty()
            || !this.cellsToFlipStraightRight(chosenCell).isEmpty()
            || !this.cellsToFlipBottomRight(chosenCell).isEmpty()
            || !this.cellsToFlipBottomLeft(chosenCell).isEmpty()
            || !this.cellsToFlipStraightLeft(chosenCell).isEmpty()
            || !this.cellsToFlipTopLeft(chosenCell).isEmpty();
  }


  /**
   * Allows the current player to pass on their turn, and the turn moves to the other player. Keeps
   * track of whether two consecutive passes have been made.
   */
  public void passMove() {
    if (!hasGameBeenStarted) {
      throw new IllegalStateException("game hasn't been started");
    }
    if (currentPlayer.equals(PlayerType.PLAYER1)) {
      player1Passed = true;
    } else {
      player2Passed = true;
    }
    this.switchTurns();
  }

  /**
   * Allows the current player to pass on their turn, and the turn moves to the other player. If
   * current player was Player 1, now the player will become Player 2.
   */
  private void switchTurns() {
    if (!hasGameBeenStarted) {
      throw new IllegalStateException("game hasn't been started");
    }
    if (this.currentPlayer.equals(PlayerType.PLAYER1)) {
      this.currentPlayer = PlayerType.PLAYER2;
    }
    else {
      this.currentPlayer = PlayerType.PLAYER1;
    }
  }


  /**
   * Checks whether both players have passed their turns consecutively to then cause the game to
   * be over.
   * @return true if both players have passed in a row
   */
  private boolean didTwoPlayersPass() {

    if (player1Passed && player2Passed) {
      this.did2PlayersPassCon = true;
    }
    return this.did2PlayersPassCon;
  }

  /**
   * Checks whether the chosen cell to make a move on has two neighboring cells in its top-right
   * path, where the q coordinate increases by one and the r coordinate decreases by one
   * consecutively in the path.
   * @param chosenCell the empty cell to be played on
   * @return true or false
   */
  //CHECKING FOR THE TOP RIGHT SIDE
  private boolean doesCellHaveTwoNeighborsTopRight(Cell chosenCell) {
    return this.doesCellHaveTwoNeighborsIncreasingQ(chosenCell, 1, -1);
  }

  /**
   * Gets the list of cells starting with the first neighboring cell in the chosen cell's top
   * right path through the first cell in the path that has the same player state as the chosen
   * cell's. Adds the consecutive cells in its path to an initially empty list and recurses until
   * finding the cell with the chosen cell's state.
   * @param chosenCell the cell to get the path of neighboring cells from
   * @return the list of cells in the chosen's top right path
   */
  private List<Cell> cellsToFlipTopRight(Cell chosenCell) {
    //make a list of cells starting with the first top right cell
    // through the first cell that has the same color as the current player
    //assuming that it has two
    List<Cell> ans = new ArrayList<>(); // double check

    if (this.doesCellHaveTwoNeighborsTopRight(chosenCell)) {

      int count = chosenCell.getRCoord();
      for (int col = chosenCell.getQCoord(); col < boardSize; col++) {
        count--;
        if (this.cellExistsInBoard(gameBoard.getCells(), col + 1, count)) {
          if (this.gameBoard.getCells()[col + 1][count].getStateOfCell()
                  .equals(Cell.CellState.EMPTY)) {
            break;
          }
          //PLAYER 1 WHITE,  PLAYER 2 BLACK
          if (currentPlayer.equals(PlayerType.PLAYER1) &&
                  gameBoard.getCells()[col + 1][count].getColor().equals(Color.white)) {
            break;
          }
          if (currentPlayer.equals(PlayerType.PLAYER2) &&
                  gameBoard.getCells()[col + 1][count].getColor().equals(Color.black)) {
            break;
          }
          ans.add(gameBoard.getCells()[col + 1][count]);
          //add the cell with the row and count to the empty list and
          // keep doing that until you find one with the chosen cell state (color)
        }
      }
      return ans;
    } else {
      return ans;
    }
  }

  /**
   * Checks whether the chosen cell to make a move on has two neighboring cells in its direct-right
   * path, where the q coordinate increases by one and the r coordinate stays the same
   * consecutively in the path.
   * @param chosenCell the empty cell to be played on
   * @return true or false if the cell has two consecutive cells to its right
   */
  //STUFF FOR MOVING STRAIGHT TO THE RIGHT / JUST RIGHT
  private boolean doesCellHaveTwoNeighborsStraightRight(Cell chosenCell) {
    return this.doesCellHaveTwoNeighborsIncreasingQ(chosenCell, 1, 0);
  }


  /**
   * Gets the list of cells starting with the first neighboring cell in the chosen cell's straight
   * right path through the first cell in the path that has the same player state as the chosen
   * cell's. Adds the consecutive cells in its path to an initially empty list and recurses until
   * finding the cell with the chosen cell's state.
   * @param chosenCell the cell to get the path of neighboring cells from
   * @return the list of cells in the chosen's right path
   */
  private List<Cell> cellsToFlipStraightRight(Cell chosenCell) {
    //make a list of cells starting with the first top right cell
    // through the first cell that has the same color as the current player
    //assuming that it has two
    List<Cell> ans = new ArrayList<>(); // double check

    if (this.doesCellHaveTwoNeighborsStraightRight(chosenCell)) {

      int count = chosenCell.getRCoord();
      for (int col = chosenCell.getQCoord(); col < boardSize; col++) {
        if (this.cellExistsInBoard(gameBoard.getCells(), col + 1, count)) {
          if (this.gameBoard.getCells()[col + 1][count].getStateOfCell()
                  .equals(Cell.CellState.EMPTY)) {
            break;
          }
          //PLAYER 1 WHITE,  PLAYER 2 BLACK
          if (currentPlayer.equals(PlayerType.PLAYER1) &&
                  gameBoard.getCells()[col + 1][count].getColor().equals(Color.white)) {
            break;
          }
          if (currentPlayer.equals(PlayerType.PLAYER2) &&
                  gameBoard.getCells()[col + 1][count].getColor().equals(Color.black)) {
            break;
          }
          ans.add(gameBoard.getCells()[col + 1][count]);
          //add the cell with the row and count to the empty list and
          // keep doing that until you find one with the chosen cell state (color)
        }
      }
      return ans;
    } else {
      return ans;
    }
  }

  /**
   * Checks whether the chosen cell to make a move on has two neighboring cells in its bottom-right
   * path, where the q coordinate stays the same and the r coordinate stays increases by one
   * consecutively in the path.
   * @param chosenCell the empty cell to be played on
   * @return true or false if the cell has two consecutive cells to its bottom right
   */
  //STUFF FOR DOWN RIGHT NEIGHBORS
  private boolean doesCellHaveTwoNeighborsBottomRight(Cell chosenCell) {
    return this.doesCellHaveTwoNeighborsIncreasingQ(chosenCell, 0, 1);
  }

  /**
   * Gets the list of cells starting with the first neighboring cell in the chosen cell's
   * bottom right path through the first cell in the path that has the same player state as the
   * chosen cell's. Adds the consecutive cells in its path to an initially empty list and recurses
   * until finding the cell with the chosen cell's state.
   * @param chosenCell the cell to get the path of neighboring cells from
   * @return the list of cells in the chosen's bottom right path
   */
  private List<Cell> cellsToFlipBottomRight(Cell chosenCell) {
    //make a list of cells starting with the first top right cell
    // through the first cell that has the same color as the current player
    //assuming that it has two
    List<Cell> ans = new ArrayList<>(); // double check

    if (this.doesCellHaveTwoNeighborsBottomRight(chosenCell)) {

      int count = chosenCell.getQCoord();
      for (int row = chosenCell.getRCoord(); row < boardSize; row++) {
        if (this.cellExistsInBoard(gameBoard.getCells(), count, row + 1)) {
          if (this.gameBoard.getCells()[count][row + 1].getStateOfCell()
                  .equals(Cell.CellState.EMPTY)) {
            break;
          }
          //PLAYER 1 WHITE,  PLAYER 2 BLACK
          if (currentPlayer.equals(PlayerType.PLAYER1) &&
                  gameBoard.getCells()[count][row + 1].getColor().equals(Color.white)) {
            break;
          }
          if (currentPlayer.equals(PlayerType.PLAYER2) &&
                  gameBoard.getCells()[count][row + 1].getColor().equals(Color.black)) {
            break;
          }
          ans.add(gameBoard.getCells()[count][row + 1]);
          //add the cell with the row and count to the empty list and
          // keep doing that until you find one with the chosen cell state (color)
        }
      }
      return ans;
    } else {
      return ans;
    }
  }


  /**
   * Checks whether the chosen cell to make a move on has two neighboring cells in its top-left
   * path, where the q coordinate stays the same and the r coordinate decreases by one
   * consecutively in the path.
   * @param chosenCell the empty cell to be played on
   * @return true or false if the cell has two consecutive cells to its top left
   */
  //STUFF FOR TOP LEFT NEIGHBORS
  private boolean doesCellHaveTwoNeighborsTopLeft(Cell chosenCell) {
    return this.doesCellHaveTwoNeighborsIncreasingQ(chosenCell, 0, -1);
  }

  /**
   * Gets the list of cells starting with the first neighboring cell in the chosen cell's
   * top left path through the first cell in the path that has the same player state as the
   * chosen cell's. Adds the consecutive cells in its path to an initially empty list and recurses
   * until finding the cell with the chosen cell's state.
   * @param chosenCell the cell to get the path of neighboring cells from
   * @return the list of cells in the chosen's top left path
   */
  private List<Cell> cellsToFlipTopLeft(Cell chosenCell) {
    //make a list of cells starting with the first top right cell
    // through the first cell that has the same color as the current player
    //assuming that it has two
    List<Cell> ans = new ArrayList<>(); // double check

    if (this.doesCellHaveTwoNeighborsTopLeft(chosenCell)) {

      int count = chosenCell.getQCoord();
      for (int row = chosenCell.getRCoord(); row > 0; row--) {
        if (this.cellExistsInBoard(gameBoard.getCells(), count, row - 1)) {
          if (this.gameBoard.getCells()[count][row - 1].getStateOfCell()
                  .equals(Cell.CellState.EMPTY)) {
            break;
          }
          //PLAYER 1 WHITE,  PLAYER 2 BLACK
          if (currentPlayer.equals(PlayerType.PLAYER1) &&
                  gameBoard.getCells()[count][row - 1].getColor().equals(Color.white)) {
            break;
          }
          if (currentPlayer.equals(PlayerType.PLAYER2) &&
                  gameBoard.getCells()[count][row - 1].getColor().equals(Color.black)) {
            break;
          }
          ans.add(gameBoard.getCells()[count][row - 1]);
          //add the cell with the row and count to the empty list and
          // keep doing that until you find one with the chosen cell state (color)
        }
      }
      return ans;
    } else {
      return ans;
    }
  }

  //STUFF FOR STRAIGHT LEFT NEIGHBORS
  /**
   * Checks whether the chosen cell to make a move on has two neighboring cells in its direct left
   * path, where the q coordinate stays the same and the r coordinate decreases by one
   * consecutively in the path.
   * @param chosenCell the empty cell to be played on
   * @return true or false if the cell has two consecutive cells to its left
   */
  private boolean doesCellHaveTwoNeighborsStraightLeft(Cell chosenCell) {
    return this.doesCellHaveTwoNeighborsDecreasingQ(chosenCell, -1, 0);
  }

  /**
   * Checks whether the chosen cell to make a move on has two neighboring cells in its direct-left
   * path, where the q coordinate decreases by one and the r coordinate stays the same
   * consecutively in the path.
   * @param chosenCell the empty cell to be played on
   * @return true or false if the cell has two consecutive cells to its left
   */
  private List<Cell> cellsToFlipStraightLeft(Cell chosenCell) {
    //make a list of cells starting with the first top right cell
    // through the first cell that has the same color as the current player
    //assuming that it has two
    List<Cell> ans = new ArrayList<>(); // double check

    if (this.doesCellHaveTwoNeighborsStraightLeft(chosenCell)) {

      int count = chosenCell.getRCoord();
      for (int col = chosenCell.getQCoord(); col > 0; col--) {
        if (this.cellExistsInBoard(gameBoard.getCells(),
                col - 1, count)) {
          if (this.gameBoard.getCells()[col - 1][count].getStateOfCell()
                  .equals(Cell.CellState.EMPTY)) {
            break;
          }
          //PLAYER 1 WHITE,  PLAYER 2 BLACK
          if (currentPlayer.equals(PlayerType.PLAYER1) &&
                  gameBoard.getCells()[col - 1][count].getColor().equals(Color.white)) {
            break;
          }
          if (currentPlayer.equals(PlayerType.PLAYER2) &&
                  gameBoard.getCells()[col - 1][count].getColor().equals(Color.black)) {
            break;
          }
          ans.add(gameBoard.getCells()[col - 1][count]);
          //add the cell with the row and count to the empty list and
          // keep doing that until you find one with the chosen cell state (color)
        }
      }
      return ans;
    } else {
      return ans;
    }
  }
  /**
   * Checks whether the chosen cell to make a move on has two neighboring cells in its bottom-left
   * path, where the q coordinate decreases by one and the r coordinate increases by one
   * consecutively in the path.
   * @param chosenCell the empty cell to be played on
   * @return true or false if the cell has two consecutive cells to its bottom left
   */

  //STUFF FOR BOTTOM LEFT NEIGHBORS
  private boolean doesCellHaveTwoNeighborsBottomLeft(Cell chosenCell) {
    return this.doesCellHaveTwoNeighborsDecreasingQ(chosenCell, -1, 1);
  }

  /**
   * Gets the list of cells starting with the first neighboring cell in the chosen cell's
   * bottom left path through the first cell in the path that has the same player state as the
   * chosen cell's. Adds the consecutive cells in its path to an initially empty list and recurses
   * until finding the cell with the chosen cell's state.
   * @param chosenCell the cell to get the path of neighboring cells from
   * @return the list of cells in the chosen's bottom left path
   */
  //double check coords but they are changed.
  private List<Cell> cellsToFlipBottomLeft(Cell chosenCell) {
    //make a list of cells starting with the first top right cell
    // through the first cell that has the same color as the current player
    //assuming that it has two
    List<Cell> ans = new ArrayList<>(); // double check

    if (this.doesCellHaveTwoNeighborsBottomLeft(chosenCell)) {
      int count = chosenCell.getQCoord();
      for (int row = chosenCell.getRCoord(); row < boardSize; row++) {
        count--;
        if (this.cellExistsInBoard(this.getGameBoard().getCells(),
                count, row + 1)) {
          if (this.gameBoard.getCells()[count][row + 1].getStateOfCell()
                  .equals(Cell.CellState.EMPTY)) {
            break;
          }
          //PLAYER 1 WHITE,  PLAYER 2 BLACK
          if (currentPlayer.equals(PlayerType.PLAYER1) &&
                  gameBoard.getCells()[count][row + 1].getColor().equals(Color.white)) {
            break;
          }
          if (currentPlayer.equals(PlayerType.PLAYER2) &&
                  gameBoard.getCells()[count][row + 1].getColor().equals(Color.black)) {
            break;
          }
          ans.add(gameBoard.getCells()[count][row + 1]);
          //add the cell with the row and count to the empty list and
          // keep doing that until you find one with the chosen cell state (color)
        }
      }
      return ans;
    } else {
      return ans;
    }
  }
  //this would work for all the different sides

  /**
   * Checks whether the wanted cell exists in the 2d array of cells in the hexagonal board.
   * Checks whether the cell exists in increasing columns from the center of the board.
   * @param cells the 2d array of cells
   * @param q the q coord we are looking for
   * @param r the r coord we are looking for
   * @return true or false, if the target cell exists in the board
   */
  private boolean cellExistsInBoard(Cell[][] cells, int q, int r) {
    return cells[q][r] != null && q < this.boardSize && q >= 0 && r < this.boardSize && r >= 0;

  }


  /*
  private boolean cellExistsInBoardForColDecreasing(Cell[][] cells, Cell target) {
    try {
      for (int col = 0; col < cells.length; col++) {
        for (int row = 0; row < cells.length; row++) {
          if (cells[row][col] == null) {
            break;
          }
          if (cells[row][col].getQCoord() == target.getQCoord()
                  && cells[row][col].getRCoord() == target.getRCoord()) {
            return true;
          }
        }
      }
    } catch (NullPointerException nullPointerException) {
      //null
    }
    return false;
  }
   */

  /**
   * Flips the given list of cells to its opposite color (in the color of chosen cell) when a legal
   * move is made.
   * @param listOfCells the consecutive cells in the chosen cells path up to a cell of its own state
   */
  private void flipPathOfNeighbors(List<Cell> listOfCells) {
    for (Cell cell : listOfCells) {
      cell.flipMyColor();
    }
  }


  /**
   * Abstracted method that checks whether the given cell has two consecutive cells in any given
   * direction of increasing columns, given the two coordinates to check by. Looks at the next
   * consecutive neighboring cell in path of given cell to make sure it exists. Then looks at the
   * next consecutive cell of the one before to make sure it exists. For example if the
   * qToChangeBy passed in is 1 and the rToChangeBy is -1, returns whether the cell has two
   * consecutive top right neighbors in its path.
   * @param chosencell the cell to make a move on
   * @param qToChangeBy the q to change location by
   * @param rToChangeBy the r to change location by
   * @return true if two consecutive neighbors exist in path, false if not
   */
  //abstract method
  private boolean doesCellHaveTwoNeighborsIncreasingQ(Cell chosencell,
                                                      int qToChangeBy, int rToChangeBy) {
    try {
      if (this.isChosenCellOrNeighborsNull(chosencell, qToChangeBy, rToChangeBy)) {
        return false;
      }
      //look at the top right cell of the given cell to make sure it exists
      //look at the top right cell of that cell to make sure it exists
      for (int row = 0; row < gameBoard.getCells().length; row++) {
        for (int col = 0; col < gameBoard.getCells().length; col++) {
          if (gameBoard.getCells()[col][row] == null) {
            break;
          }
          if (cellExistsInBoard(gameBoard.getCells(),chosencell.getQCoord() + qToChangeBy,
                                  chosencell.getRCoord() + rToChangeBy)
                  && cellExistsInBoard(gameBoard.getCells(),chosencell.getQCoord()
                          + (2 * qToChangeBy),chosencell.getRCoord() + (2 * rToChangeBy))) {
            return true;
          }
        }
      }
    } catch (IndexOutOfBoundsException | NullPointerException exception) {
      // throws exception
    }
    return false;
  }

  /**
   * Abstracted method that checks whether the given cell has two consecutive cells in any given
   * direction of decreasing columns, given the two coordinates to check by. Looks at the next
   * consecutive neighboring cell in path of given cell to make sure it exists. Then looks at the
   * next consecutive cell of the one before to make sure it exists.For example if the
   * qToChangeBy passed in is -1 and the rToChangeBy is 1, returns whether the cell has two
   * consecutive bottom left neighbors in its path.
   * @param chosencell the cell to make a move on
   * @param qToChangeBy the q to change location by
   * @param rToChangeBy the r to change location by
   * @return true if two consecutive neighbors exist in path, false if not
   */
  private boolean doesCellHaveTwoNeighborsDecreasingQ(Cell chosencell,
                                                      int qToChangeBy, int rToChangeBy) {
    try {
      if (this.isChosenCellOrNeighborsNull(chosencell, qToChangeBy, rToChangeBy)) {
        return false;
      }
      //look at the top right cell of the given cell to make sure it exists
      //look at the top right cell of that cell to make sure it exists
      for (int row = 0; row < gameBoard.getCells().length; row++) {
        for (int col = 0; col < gameBoard.getCells().length; col++) {
          if (gameBoard.getCells()[col][row] == null) {
            break;
          }
          if (cellExistsInBoard(gameBoard.getCells(), chosencell.getQCoord() + qToChangeBy,
                                  chosencell.getRCoord() + rToChangeBy)
                  && cellExistsInBoard(gameBoard.getCells(),chosencell.getQCoord()
                          + (2 * qToChangeBy),chosencell.getRCoord() + (2 * rToChangeBy))) {
            return true;
          }
        }
      }
    } catch (IndexOutOfBoundsException | NullPointerException exception) {
      // throws exception
    }
    return false;
  }

  /**
   * Abstracted method that checks whether in case the chosen cell is null, or if its
   * neighbors are null in the hexagonal board.
   * @param chosenCell the cell to make a move on
   * @param qToChangeBy the q by which to get the next cell in path
   * @param rToChangeBy the r by which to get the next cell in path
   * @return true if given cell or its two consecutive cells in path are null, else false
   */
  private boolean isChosenCellOrNeighborsNull(Cell chosenCell, int qToChangeBy, int rToChangeBy) {
    try {
      Cell nextNeighbor = gameBoard.getCells()[chosenCell.getQCoord() +
              qToChangeBy][chosenCell.getRCoord() + rToChangeBy];
      Cell nextNextNeighbor = gameBoard.getCells()
              [chosenCell.getQCoord() + (2 * qToChangeBy)][chosenCell.getRCoord()
              + (2 * rToChangeBy)];
      if (chosenCell == null || nextNeighbor == null
              || nextNextNeighbor == null) {
        return true;
      }
    } catch (IndexOutOfBoundsException indexOutOfBoundsException) {
      //catches the exception
    }
    return false;
  }
  
}
