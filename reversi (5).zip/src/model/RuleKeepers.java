package model;

/**
 * Acts as a manual for the rules of a version of the game of Reversi.
 */
public final class RuleKeepers {

  /**
   * Constructs a manual for ensuring the rules of the game are followed.
   */
  public RuleKeepers() {
    //I left this empty because you can simply use values to input in each
    // individual case.
  }

  /**
   * Copy constructor for RuleKeepers that returns a copy of this.
   */
  public RuleKeepers(RuleKeepers other) {
    //
  }

  /**
   * Ensures that a board with negative or even sizes cannot be created for the game.
   * @param dimension the user's preferred board size
   * @throws IllegalArgumentException if an invalid size is given
   */
  public void cannotMakeBoardNegOrEvenInput(int dimension) {
    if (dimension <= 0
            || dimension % 2 == 0) {
      throw new IllegalArgumentException("Cannot have invalid input for boardsize." +
              " Please try again with a new dimension");
    }
  }

  /**
   * Ensures that a board with negative or even sizes cannot be created for the game.
   * @param model the model of the reversi game that we are playing.
   * @throws IllegalArgumentException if an invalid size is given
   */
  public void cannotMakeBoardNegOrEvenInputOnModel(ReversiModel model) {
    if (model.getGameBoard().getCells().length <= 0
            || model.getGameBoard().getCells().length % 2 == 0) {
      throw new IllegalArgumentException("Cannot have invalid input for boardsize." +
              " Please try again with a new dimension");
    }
  }


  /**
   * Ensures that when a move is made on a cell, that cell is empty with no disks played in it ]
   * already.
   * @param chosenCell the cell to make a move on
   */
  public void chosenCellForMoveMustBeEmpty(Cell chosenCell) {
    if (chosenCell.getStateOfCell().equals(Cell.CellState.WHITEFILLED)
            || chosenCell.getStateOfCell().equals(Cell.CellState.BLACKFILLED)) {
      throw new IllegalArgumentException("cannot move on an already filled cell");
    }
  }

  /**
   * Ensures that there are only two players for this version of the game.
   * @param model the version of the game being played
   * @param player1 the first player of the game
   * @param player2 the second player of the game
   */
  public void currentPlayerMustBePlayer1OrPlayer2(ReversiModel model,
                                                  Player player1, Player player2) {
    if (!model.getCurrentPlayer().equals(player1) ||
        !model.getCurrentPlayer().equals(player2)) {
      throw new IllegalStateException("There are only two players in this game");
    }
  }

  /**
   * Ensures that a move cannot be made after both players have passed consecutively and the
   * game is now over.
   * @param twoPlayersPassed true if both players have passed in a row
   */
  public void cannotMoveAfterTwoPasses(boolean twoPlayersPassed) {
    if (twoPlayersPassed) {
      throw new IllegalStateException("cannot move after game is over");
    }

  }

  //act almost like any time you need to check a rule,
  //you go to the rule keepers

  // if the cells coordinates/value is null, then does it have neighbor is false immediately
}
