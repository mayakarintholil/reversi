package strategies;

import model.Cell;
import model.Coordinate;
import model.IReversi;
import model.ReversiModel;

/**
 * A class that represents a key strategy to capture as many pieces on this turn as possible,
 * given a player
 * and a game.
 */
public class CaptureMostOnThisTurn implements ReversiStrategy {

  /**
   * Constructs the strategy of trying to capture the most pieces on this player's turn.
   */
  public CaptureMostOnThisTurn() {
    //empty constructor
  }

  /**
   * Chooses the best move to make for the given player on their turn - checks which cell flips 
   * the most cells in favor of the given player. If many coordinates on the board have the same 
   * highest number of cells flipped, the topmost-leftmost coordinate is returned by the strategy.
   * @param model the version of the model to be searching through
   * @param player the Player to choose the best move for 
   * @return the most optimal coordinate that flips the most cells in favor of the given player. 
   *        Chooses the topmost and leftmost coordinate in the case of ties. 
   */
  @Override
  public Coordinate chooseMove(IReversi model, ReversiModel.PlayerType player) {

    //ISSUE: every time move is called - the player switches, so how to keep that the same


    //given the current player, go through each empty cell on the board
    //for every iteration, make a copy of the board and then try calling move and getScore
    //if this getScore is higher than the previous one, store this getScore's coordinate
    //return the coordinate
    Coordinate bestMoveCoord = new Coordinate(0, 0);
    int greatestScoreFromOneMove = 0;
    IReversi copiedModel;

    for (int row = model.getBoardSize() - 1; row >= 0; row--) {
      for (int col = model.getBoardSize() - 1; col >= 0; col--) {
        copiedModel = new ReversiModel((ReversiModel) model);
        if (copiedModel.getGameBoard().getCells()[col][row] == null
                || !copiedModel.getGameBoard().getCells()[col][row].getStateOfCell()
                .equals(Cell.CellState.EMPTY)) {
          continue;
        }
        else {
          copiedModel.completeMove(copiedModel.getGameBoard().getCells()[col][row]);
          copiedModel.passMove();
          if (copiedModel.getCurrentPlayerScore(player) > greatestScoreFromOneMove) {
            greatestScoreFromOneMove = copiedModel.getCurrentPlayerScore(player);
            bestMoveCoord = copiedModel.getGameBoard().getCells()[col][row].getCellsCoordinate();
          }
        }
      }
    }
    return bestMoveCoord;
  }
}


