package strategies;

import model.Coordinate;
import model.IReversi;
import model.ReversiModel;

/**
 * A Strategy interface for choosing where to play next for the given player in a game of Reversi.
 */
public interface ReversiStrategy {
  Coordinate chooseMove(IReversi model, ReversiModel.PlayerType player);

}