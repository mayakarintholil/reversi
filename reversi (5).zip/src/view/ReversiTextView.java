package view;

import model.Board;
import model.Cell;
import model.IReversi;

/**
 * This represents a Textual view specifically for the reversi game that we have created.
 */
public class ReversiTextView implements TextView {

  private final IReversi model;

  /**
   * Constructs a textual view given the model of the current game. 
   * @param model the game to present 
   */
  public ReversiTextView(IReversi model) {
    this.model = model;
  }


  /**
   * Returns a string-based view of the Reversi game model at any point of playing the game.
   * @return the String textual view of the board
   */
  @Override
  public String toString() {
    //white is X, black is 0, empty cells are _

    Board boardToDisplay = this.model.getGameBoard();
    StringBuilder stringBoard = new StringBuilder();
    String countSpaces = " ";
    for (int row = 0; row < boardToDisplay.getCells().length; row++) {
      stringBoard.append("\n"); //add a new line at end of each row
      if (row > (int) Math.floor(boardToDisplay.getCells().length / 2.0)) {
        //add count number of spaces to each new row after middle row
        stringBoard.append(countSpaces);
        countSpaces += " ";
      }

      for (int col = 0; col < boardToDisplay.getCells().length; col++) {
        stringBoard.append(" ");

        if (boardToDisplay.getCells()[col][row] == null) {
          stringBoard.append("");
        }
        else if (boardToDisplay.getCells()[col][row].
                getStateOfCell().equals(Cell.CellState.EMPTY)) {
          stringBoard.append("_");
        }
        else if (boardToDisplay.getCells()[col][row]
                .getStateOfCell().equals(Cell.CellState.BLACKFILLED)) {
          stringBoard.append("O");
        }
        else if (boardToDisplay.getCells()[col][row]
                .getStateOfCell().equals(Cell.CellState.WHITEFILLED)) {
          stringBoard.append("X");
        }
      }
    }
    if (model.isGameOver()) {
      stringBoard.append("\n GAME OVER!!!!!!!!!!!!!!!!");
    }

    return stringBoard.toString();

  }
}