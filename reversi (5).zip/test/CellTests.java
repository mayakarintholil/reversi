import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.awt.Color;

import model.Cell;
import model.Coordinate;

/**
 * Tests for the cell class and its coordinates.
 */
public class CellTests {

  Cell cellEmpty;

  Cell cellBlack;

  Cell cellWhite;


  @Before
  public void initData() {
    cellEmpty = new Cell(Cell.CellState.EMPTY, new Coordinate(2, 3));
    cellBlack = new Cell(Cell.CellState.BLACKFILLED, new Coordinate(0, 2));
    cellWhite = new Cell(Cell.CellState.WHITEFILLED, new Coordinate(4, 2));

  }

  @Test
  public void testGetColor() {
    Assert.assertEquals(Color.BLACK, cellBlack.getColor());
    Assert.assertEquals(Color.WHITE, cellWhite.getColor());
    Assert.assertThrows("There is no colored piece on an empty cell",
            IllegalStateException.class, () -> cellEmpty.getColor());

  }


  @Test
  public void testGetQCoord() {
    Assert.assertEquals(cellBlack.getQCoord(), 0);
    Assert.assertEquals(cellEmpty.getQCoord(), 2);
    Assert.assertEquals(cellWhite.getQCoord(), 4);

  }

  @Test
  public void testGetRCoord() {
    Assert.assertEquals(cellBlack.getRCoord(), 2);
    Assert.assertEquals(cellEmpty.getRCoord(), 3);
    Assert.assertEquals(cellWhite.getRCoord(), 2);
  }

  @Test
  public void getCellCoordinate() {
    Assert.assertEquals(cellBlack.getCellsCoordinate(),
            new Coordinate(0, 2));
    Assert.assertEquals(cellEmpty.getCellsCoordinate(),
            new Coordinate(4, 2));
    Assert.assertEquals(cellWhite.getCellsCoordinate(),
            new Coordinate(2, 3));

  }

  //test fill my color

  //test flipcell

}
