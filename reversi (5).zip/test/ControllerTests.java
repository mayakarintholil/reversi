import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import controller.ControllerFeatures;
import controller.ReversiController;
import model.Cell;
import model.Coordinate;
import model.HumanPlayer;
import model.IReversi;
import model.MachinePlayer;
import model.Player;
import model.ReversiModel;
import view.ReversiFrame;
import view.ReversiView;

/**
 * Tests for the controller and features interfaces for Reversi.
 */
public class ControllerTests {
  IReversi model;
  ReversiView view1;
  ReversiView view2;
  Player player1;
  Player player2;
  ControllerFeatures controller1;
  ControllerFeatures controller2;

  @Before
  public void initData() {
    model = new ReversiModel(5);
    view1 = new ReversiFrame(model);
    view2 = new ReversiFrame(model);
    player1 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER1);
    player2 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER2);
    controller1 = new ReversiController(model, view1, player1);
    controller2 = new ReversiController(model, view2, player2);
  }


  @Before
  public void initData2() {
    model = new ReversiModel();
    view1 = new ReversiFrame(model);
    view2 = new ReversiFrame(model);
    player1 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER1);
    player2 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER2);
    controller1 = new ReversiController(model, view1, player1);
    controller2 = new ReversiController(model, view2, player2);
  }

  @Test
  public void testFeaturesMakeMoveUpdatesModelPlayer1() {
    //player1's turn
    initData();
    controller1.makeMove();
    Assert.assertEquals(model.getGameBoard().getCells()[view1.getSelectedCellToMoveOn().getQ()]
            [view1.getSelectedCellToMoveOn().getR()].getStateOfCell(), Cell.CellState.WHITEFILLED);

  }

  @Test
  public void testFeaturesMakeMoveUpdatesNeighborsPlayer1() {
    initData();

    Assert.assertEquals(model.getGameBoard().getCells()[2]
            [1].getStateOfCell(), Cell.CellState.WHITEFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[3]
            [1].getStateOfCell(), Cell.CellState.WHITEFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[3]
            [2].getStateOfCell(), Cell.CellState.WHITEFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[4]
            [1].getStateOfCell(), Cell.CellState.WHITEFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[2]
            [2].getStateOfCell(), Cell.CellState.EMPTY);
  }

  @Test
  public void testRepeatedMakeMovePlayer1Fails() {
    initData();
    Assert.assertThrows(IllegalStateException.class, () -> controller1.makeMove());
  }


  @Test
  public void testFeaturesMakeMoveUpdatesModelPlayer2() {
    //player2's turn
    initData();
    controller2.makeMove();
    Assert.assertEquals(model.getGameBoard().getCells()[view2.getSelectedCellToMoveOn().getQ()]
            [view2.getSelectedCellToMoveOn().getR()].getStateOfCell(), Cell.CellState.BLACKFILLED);

  }

  @Test
  public void testFeaturesMakeMoveUpdatesNeighborsPlayer2() {
    initData();
    Assert.assertEquals(model.getGameBoard().getCells()[1]
            [1].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[1]
            [2].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[1]
            [3].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[2]
            [1].getStateOfCell(), Cell.CellState.BLACKFILLED);
  }

  @Test
  public void testThrowsForMakingMoveOnNotTurn() {
    controller1.passOnTurn();
    Assert.assertThrows(IllegalArgumentException.class, () -> controller1.makeMove());
    controller2.passOnTurn();
    Assert.assertThrows(IllegalArgumentException.class, () -> controller1.makeMove());
    Assert.assertThrows(IllegalArgumentException.class, () -> controller2.makeMove());
  }


  @Test
  public void testFeaturesMakeMoveIllegalMovePlayer1() {
    initData2();
    controller1.makeMove();
    Assert.assertEquals(model.getGameBoard().getCells()[4]
            [1].getStateOfCell(), Cell.CellState.WHITEFILLED);
    controller2.makeMove();
    Assert.assertEquals(model.getGameBoard().getCells()[view2.getSelectedCellToMoveOn().getQ()]
            [view2.getSelectedCellToMoveOn().getR()].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertThrows(IllegalArgumentException.class, () -> controller1.makeMove());

  }


  @Test
  public void testFeaturesMakeMoveIllegalMovePlayer2() {
    initData2();
    controller1.makeMove();
    Assert.assertEquals(model.getGameBoard().getCells()[4]
            [1].getStateOfCell(), Cell.CellState.WHITEFILLED);
    controller2.makeMove();
    Assert.assertEquals(model.getGameBoard().getCells()[view2.getSelectedCellToMoveOn().getQ()]
            [view2.getSelectedCellToMoveOn().getR()].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertThrows(IllegalArgumentException.class, () ->
            model.completeMove(new Cell(Cell.CellState.EMPTY, new Coordinate(4, 1))));
  }

  @Test
  public void testPlayerAssignedTypeCorrectly() {
    Assert.assertEquals(player1.getPlayerType(), ReversiModel.PlayerType.PLAYER1);
    Assert.assertEquals(player2.getPlayerType(), ReversiModel.PlayerType.PLAYER2);
  }

  @Test
  public void testFeaturesPassOnTurnSwitchesCurrentPlayer1() {
    initData2();
    controller1.makeMove();
    Assert.assertEquals(model.getCurrentPlayer(), ReversiModel.PlayerType.PLAYER2);
    controller2.passOnTurn();
    Assert.assertEquals(model.getCurrentPlayer(), ReversiModel.PlayerType.PLAYER1);
  }

  @Test
  public void testFeaturesPassOnTurnSwitchesCurrentPlayer2() {
    initData2();
    controller1.makeMove();
    Assert.assertEquals(model.getCurrentPlayer(), ReversiModel.PlayerType.PLAYER2);
    controller2.makeMove();
    controller1.passOnTurn();
    Assert.assertEquals(model.getCurrentPlayer(), ReversiModel.PlayerType.PLAYER2);
  }

  @Test
  public void testFeaturesPassOnTurnNotifiesNextPlayer() {
    initData();
    controller1.makeMove();
    //notify player 2 it is their turn
    Assert.assertThrows(IllegalStateException.class, () -> player1.getMeMyNextMove());
    controller2.makeMove();
    Assert.assertEquals(player1.getMeMyNextMove(), new Coordinate(-1, -1));
    controller1.passOnTurn(); //player1 passes
    Assert.assertEquals(player2.getMeMyNextMove(), new Coordinate(-1, -1)); //player 2 turn
  }


  @Test
  public void testFeaturesMakeMoveUpdatesModelPlayer1AIs() {
    //player1's turn
    initData2AI();
    controller1.makeMove();
    Coordinate player1Move = player1.getMeMyNextMove();
    Assert.assertEquals(model.getCellContentsAt(player1Move.getQ(), player1Move.getR())
                    .getStateOfCell(),
            Cell.CellState.WHITEFILLED);
    controller2.makeMove();
    Coordinate player2Move = player2.getMeMyNextMove();
    Assert.assertEquals(model.getCellContentsAt(player2Move.getQ(), player2Move.getR())
                    .getStateOfCell(),
            Cell.CellState.BLACKFILLED);
    Assert.assertTrue(model.getCurrentPlayerScore(ReversiModel.PlayerType.PLAYER1) > 3);
    Assert.assertTrue(model.getCurrentPlayerScore(ReversiModel.PlayerType.PLAYER2) > 3);
  }

  @Test
  public void testFeaturesMakeMoveUpdatesNeighborsAIs() {
    initData2AI();
    Assert.assertEquals(model.getGameBoard().getCells()[2]
            [1].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[3]
            [1].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[3]
            [2].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[4]
            [1].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[2]
            [2].getStateOfCell(), Cell.CellState.BLACKFILLED);

    Assert.assertEquals(model.getGameBoard().getCells()[1]
            [2].getStateOfCell(), Cell.CellState.WHITEFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[1]
            [3].getStateOfCell(), Cell.CellState.WHITEFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[1]
            [1].getStateOfCell(), Cell.CellState.WHITEFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[2]
            [1].getStateOfCell(), Cell.CellState.WHITEFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[3]
            [2].getStateOfCell(), Cell.CellState.WHITEFILLED);

    Assert.assertEquals(model.getGameBoard().getCells()[2]
            [2].getStateOfCell(), Cell.CellState.EMPTY);

  }

  @Test
  public void testRepeatedMakeMoveAIPlayersFails() {
    initData2AI();
    controller1.makeMove();
    controller2.makeMove();
    controller1.passOnTurn();
    controller2.makeMove();
    Assert.assertThrows(IllegalStateException.class, () -> controller2.makeMove());
  }


  @Test
  public void testThrowsForMakingMoveOnNotTurnAIAndAI() {
    initData2AI();
    controller1.passOnTurn();
    Assert.assertThrows(IllegalArgumentException.class, () -> controller1.makeMove());
    controller2.passOnTurn();
    Assert.assertThrows(IllegalArgumentException.class, () -> controller1.passOnTurn());
    Assert.assertThrows(IllegalArgumentException.class, () -> controller1.makeMove());
    Assert.assertThrows(IllegalArgumentException.class, () -> controller2.makeMove());
  }

  @Test
  public void testFeaturesMakeMoveIllegalMovePlayer2AIs() {
    initData2AI();
    controller1.makeMove();
    Assert.assertEquals(model.getGameBoard().getCells()[4]
            [1].getStateOfCell(), Cell.CellState.WHITEFILLED);
    controller2.makeMove();
    Coordinate player2Move = player2.getMeMyNextMove();
    Assert.assertEquals(model.getCellContentsAt(player2Move.getQ(), player2Move.getR())
                    .getStateOfCell(),
            Cell.CellState.BLACKFILLED);
    Assert.assertThrows(IllegalArgumentException.class, () -> controller1.makeMove());
    Assert.assertThrows(IllegalArgumentException.class,
        () -> model.completeMove(model.getCellContentsAt(player2Move.getQ(),
                    player2Move.getR())));
  }


  @Test
  public void testPlayerAssignedTypeCorrectlyAIAndAI() {
    initData2AI();
    Assert.assertEquals(player1.getPlayerType(), ReversiModel.PlayerType.PLAYER1);
    Assert.assertEquals(player2.getPlayerType(), ReversiModel.PlayerType.PLAYER2);
  }


  @Test
  public void testFeaturesPassOnTurnSwitchesCurrentPlayer1AIs() {
    initData2AI();
    controller1.makeMove();
    Assert.assertEquals(model.getCurrentPlayer(), ReversiModel.PlayerType.PLAYER2);
    controller2.passOnTurn();
    Assert.assertEquals(model.getCurrentPlayer(), ReversiModel.PlayerType.PLAYER1);
  }

  @Test
  public void testFeaturesPassOnTurnSwitchesCurrentPlayer2AIs() {
    initDataHAndAI();
    controller1.makeMove();
    Assert.assertEquals(model.getCurrentPlayer(), ReversiModel.PlayerType.PLAYER2);
    controller2.makeMove();
    controller1.passOnTurn();
    Assert.assertEquals(model.getCurrentPlayer(), ReversiModel.PlayerType.PLAYER2);
  }

  @Test
  public void testFeaturesPassOnTurnNotifiesNextPlayerAIAndAI() {
    initData2AI();
    controller1.makeMove();
    //notify player 2 it is their turn
    Assert.assertThrows(IllegalStateException.class, () -> player1.getMeMyNextMove());
    controller2.makeMove();
    Assert.assertEquals(player1.getMeMyNextMove(), new Coordinate(2, 0));
    controller1.passOnTurn(); //player1 passes
    Assert.assertEquals(player2.getMeMyNextMove(), new Coordinate(0, 2)); //player 2 turn
  }

  //AI and AI Players
  @Before
  public void initData2AI() {
    model = new ReversiModel(5);
    view1 = new ReversiFrame(model);
    view2 = new ReversiFrame(model);
    player1 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER1);
    player2 = new MachinePlayer(model, ReversiModel.PlayerType.PLAYER2);
    controller1 = new ReversiController(model, view1, player1);
    controller2 = new ReversiController(model, view2, player2);
  }

  @Test
  public void testFeaturesMakeMoveUpdatesModelPlayer1AI() {
    //player1's turn
    initDataHAndAI();
    controller1.makeMove();
    controller2.makeMove();
    Coordinate player2Move = player2.getMeMyNextMove();
    Assert.assertEquals(model.getCellContentsAt(player2Move.getQ(), player2Move.getR())
                    .getStateOfCell(),
            Cell.CellState.BLACKFILLED);
    Assert.assertTrue(model.getCurrentPlayerScore(ReversiModel.PlayerType.PLAYER2) > 3);

  }

  @Test
  public void testFeaturesMakeMoveUpdatesNeighborsAI() {
    initDataHAndAI();
    Assert.assertEquals(model.getGameBoard().getCells()[2]
            [1].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[3]
            [1].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[3]
            [2].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[4]
            [1].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[2]
            [2].getStateOfCell(), Cell.CellState.BLACKFILLED);
  }

  @Test
  public void testRepeatedMakeMoveAIPlayerFails() {
    initDataHAndAI();
    controller1.makeMove();
    controller2.makeMove();
    controller1.passOnTurn();
    controller2.makeMove();
    Assert.assertThrows(IllegalStateException.class, () -> controller2.makeMove());
  }


  @Test
  public void testFeaturesMakeMoveUpdatesModelPlayer1WithAI() {
    //player2's turn
    initDataHAndAI();
    controller1.makeMove();
    Assert.assertEquals(model.getGameBoard().getCells()[view1.getSelectedCellToMoveOn().getQ()]
            [view1.getSelectedCellToMoveOn().getR()].getStateOfCell(), Cell.CellState.WHITEFILLED);

  }

  @Test
  public void testFeaturesMakeMoveUpdatesNeighborsPlayer2AI() {
    initDataHAndAI();
    Assert.assertEquals(model.getGameBoard().getCells()[1]
            [1].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[1]
            [2].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[1]
            [3].getStateOfCell(), Cell.CellState.BLACKFILLED);
    Assert.assertEquals(model.getGameBoard().getCells()[2]
            [1].getStateOfCell(), Cell.CellState.BLACKFILLED);
  }

  @Test
  public void testThrowsForMakingMoveOnNotTurnHAndAI() {
    controller1.passOnTurn();
    Assert.assertThrows(IllegalArgumentException.class, () -> controller1.makeMove());
    controller2.passOnTurn();
    Assert.assertThrows(IllegalArgumentException.class, () -> controller1.passOnTurn());
    Assert.assertThrows(IllegalArgumentException.class, () -> controller1.makeMove());
    Assert.assertThrows(IllegalArgumentException.class, () -> controller2.makeMove());
  }

  @Test
  public void testFeaturesMakeMoveIllegalMovePlayer2AI() {
    initDataHAndAI();
    controller1.makeMove();
    Assert.assertEquals(model.getGameBoard().getCells()[4]
            [1].getStateOfCell(), Cell.CellState.WHITEFILLED);
    controller2.makeMove();
    Coordinate player2Move = player2.getMeMyNextMove();
    Assert.assertEquals(model.getCellContentsAt(player2Move.getQ(), player2Move.getR())
                    .getStateOfCell(),
            Cell.CellState.BLACKFILLED);
    Assert.assertThrows(IllegalArgumentException.class, () -> controller1.makeMove());
    Assert.assertThrows(IllegalArgumentException.class, 
        () -> model.completeMove(model.getCellContentsAt(player2Move.getQ(),
                    player2Move.getR())));

  }


  @Test
  public void testPlayerAssignedTypeCorrectlyHumanAndAI() {
    Assert.assertEquals(player1.getPlayerType(), ReversiModel.PlayerType.PLAYER1);
    Assert.assertEquals(player2.getPlayerType(), ReversiModel.PlayerType.PLAYER2);
  }


  //1 Human and 1 AI Player

  @Before
  public void initDataHAndAI() {
    model = new ReversiModel(5);
    view1 = new ReversiFrame(model);
    view2 = new ReversiFrame(model);
    player1 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER1);
    player2 = new MachinePlayer(model, ReversiModel.PlayerType.PLAYER2);
    controller1 = new ReversiController(model, view1, player1);
    controller2 = new ReversiController(model, view2, player2);
  }


  @Test
  public void testFeaturesPassOnTurnSwitchesCurrentPlayer1Human() {
    initDataHAndAI();
    controller1.makeMove();
    Assert.assertEquals(model.getCurrentPlayer(), ReversiModel.PlayerType.PLAYER2);
    controller2.passOnTurn();
    Assert.assertEquals(model.getCurrentPlayer(), ReversiModel.PlayerType.PLAYER1);
  }

  @Test
  public void testFeaturesPassOnTurnSwitchesCurrentPlayer2AI() {
    initDataHAndAI();
    controller1.makeMove();
    Assert.assertEquals(model.getCurrentPlayer(), ReversiModel.PlayerType.PLAYER2);
    controller2.makeMove();
    controller1.passOnTurn();
    Assert.assertEquals(model.getCurrentPlayer(), ReversiModel.PlayerType.PLAYER2);
  }

  @Test
  public void testFeaturesPassOnTurnNotifiesNextPlayerHAndAI() {
    initDataHAndAI();
    controller1.makeMove();
    //notify player 2 it is their turn
    Assert.assertThrows(IllegalStateException.class, () -> player1.getMeMyNextMove());
    controller2.makeMove();
    Assert.assertEquals(player1.getMeMyNextMove(), new Coordinate(-1, -1));
    controller1.passOnTurn(); //player1 passes
    Assert.assertEquals(player2.getMeMyNextMove(), new Coordinate(4, 1)); //player 2 turn
  }


}
