import java.util.Objects;

import model.Coordinate;
import model.IReversi;
import model.Player;
import model.ReversiModel;
import strategies.ReversiStrategy;

/**
 * Mock for an AI Player. 
 */
public class MockAIPlayer implements Player {
  final StringBuilder log;
  final IReversi model;
  final ReversiStrategy strat;

  /**
   * Constructs a mock AI Player. 
   * @param log the log to check whether the move is returned by the strategy. 
   * @param model the model to get the move from
   * @param strat the strategy to get the coordinate with 
   */
  public MockAIPlayer(StringBuilder log, IReversi model, ReversiStrategy strat) {
    this.log = Objects.requireNonNull(log);
    this.model = model;
    this.strat = strat;
  }

  @Override
  public Coordinate getMeMyNextMove() {
    log.append("the next move is at " + strat.chooseMove(model, model.getCurrentPlayer()));
    return null;
  }

  @Override
  public ReversiModel.PlayerType getPlayerType() {
    return null;
  }
}