import java.awt.Color;

import model.IReversi;
import model.Board;
import model.Cell;
import model.Coordinate;
import model.ReversiModel;


/**
 * Represents a mock for the Reversi model that to lie about the legality of certain
 * locations or the value of such moves, to force the strategy to think that only
 * a pre-determined move is valid, and then test that it indeed returns that move. Given
 * that now it is "legal" to play on an already filled cell, the strategy should now follow this
 * condition and make the move.
 */
public class MockBogusReversiModel implements IReversi {
  private ReversiModel.PlayerType currentPlayer;
  private boolean player1Passed;
  private boolean player2Passed;

  /**
   * Constructs a mock of the Reversi model that changes the legality of a move. In this case, it
   * allows already played cells to be played on again. 
   */
  public MockBogusReversiModel() {
    this.currentPlayer = ReversiModel.PlayerType.PLAYER2;
    this.player1Passed = false;
    this.player2Passed = false;
  }

  private void switchTurns() {
    if (this.currentPlayer.equals(ReversiModel.PlayerType.PLAYER1)) {
      this.currentPlayer = ReversiModel.PlayerType.PLAYER2;
    } else {
      this.currentPlayer = ReversiModel.PlayerType.PLAYER1;
    }
  }

  @Override
  public void completeMove(Cell chosenCell) {

    if (this.currentPlayer.equals(ReversiModel.PlayerType.PLAYER1)) {
      chosenCell.fillMyCell(Color.WHITE);
    } else if (this.currentPlayer.equals(ReversiModel.PlayerType.PLAYER2)) {
      chosenCell.fillMyCell(Color.BLACK);
    } // if they make the move, switch the turn at the end

    if (currentPlayer.equals(ReversiModel.PlayerType.PLAYER1)) {
      player1Passed = false;
    } else {
      player2Passed = false;
    }
    this.switchTurns();

  }

  @Override
  public void startGame() {
    //this is startGame
  }


  @Override
  public void passMove() {
    //gonna leave this empty for now

  }

  // deliberately stubbing out getGameBoard behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public Board getGameBoard() {
    return null;
  }

  // deliberately stubbing out isGameOver behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public boolean isGameOver() {
    return false;
  }

  // deliberately stubbing out getWinner behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public ReversiModel.PlayerType getWinner() {
    return null;
  }

  // deliberately stubbing out getCurrentPlayer behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public ReversiModel.PlayerType getCurrentPlayer() {
    return null;
  }

  // deliberately stubbing out getBoardSize behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public int getBoardSize() {
    return 0;
  }

  // deliberately stubbing out getCellContentsAt behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public Cell getCellContentsAt(int q, int r) {
    return null;
  }

  // deliberately stubbing out canThisCellBePlayedOn behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public boolean canThisCellBePlayedOn(Coordinate coord) {
    return false;
  }

  // deliberately stubbing out doesCurrentPlayerHaveAnyLegalMoves behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public boolean doesCurrentPlayerHaveAnyLegalMoves() {
    return false;
  }

  // deliberately stubbing out getCurrentPlayerScore behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public int getCurrentPlayerScore(ReversiModel.PlayerType playerWhosScoreWeWant) {
    return 0;
  }
}