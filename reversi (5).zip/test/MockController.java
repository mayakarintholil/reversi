import java.util.Objects;

import controller.ControllerFeatures;

/**
 * A mock controller for Reversi that logs whether the correct moves are being visited. 
 */
public class MockController implements ControllerFeatures {
  final StringBuilder log;

  /**
   * Constructs a mock controller .
   * @param log the String log of visited methods
   */
  public MockController(StringBuilder log) {
    this.log = Objects.requireNonNull(log);
  }

  @Override
  public void makeMove() {
    this.log.append("A move has been made").append(System.lineSeparator());
    //log a move has been made
  }

  @Override
  public void passOnTurn() {
    this.log.append("A player has passed");
    // player has passed.
  }

  @Override
  public void exitProgram() {
    //exits program
  }
}