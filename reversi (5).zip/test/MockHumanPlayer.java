import java.util.Objects;

import model.Coordinate;
import model.Player;
import model.ReversiModel;
import view.ReversiView;

/**
 * A mock for the Human Player in a game of Reversi.
 */
public class MockHumanPlayer implements Player {
  final StringBuilder log;
  final ReversiView view;

  /**
   * Constructs a mock human player to see that it gets notified of turns correctly.
   * @param log the log of turn notifications
   * @param view the view of the game to get coordinate from 
   */
  public MockHumanPlayer(StringBuilder log, ReversiView view) {
    this.log = Objects.requireNonNull(log);
    this.view = view;
  }

  @Override
  public Coordinate getMeMyNextMove() {
    log.append("the next move is at " + view.getSelectedCellToMoveOn());
    return null;
  }

  @Override
  public ReversiModel.PlayerType getPlayerType() {
    return null;
  }
}