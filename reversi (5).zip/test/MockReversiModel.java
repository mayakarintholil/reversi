import java.util.Objects;

import model.Board;
import model.Cell;
import model.Coordinate;
import model.IReversi;
import model.ReversiModel;

/**
 * A mock of the Reversi model to record a transcript of which coordinates were inspected by your 
 *  strategy, and then test whether that transcript contains all the necessary coordinates. The 
 *  transcript is in the src file and is called strategy-transcript and tests whether the correct
 *  log is appended on a game with a board size of 5. 
 */
public class MockReversiModel implements IReversi {
  private final Board gameBoard;
  final StringBuilder log;

  public MockReversiModel(StringBuilder log) {
    this.gameBoard = new Board();
    this.log = Objects.requireNonNull(log);
  }

  @Override
  public void completeMove(Cell chosenCell) {
    for (int row = gameBoard.getCells().length - 1; row >= 0; row--) {
      for (int col = gameBoard.getCells().length - 1; col >= 0; col--) {
        if (gameBoard.getCells()[col][row].getStateOfCell().equals(Cell.CellState.EMPTY)) {
          this.log.append(this.gameBoard.getCells()[col][row])
                  .append("has been visited by strategy 1").append(System.lineSeparator());

        }
      }
    }
  }

  @Override
  public void startGame() {
    //stubs startGame
  }

  @Override
  public void passMove() {
    //not gonna do anything here :)
    this.log.append("I passed my turn so the other player can play.");

  }

  // deliberately stubbing out getGameBoard behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public Board getGameBoard() {
    return null;
  }

  // deliberately stubbing out isGameOver behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public boolean isGameOver() {
    return false;
  }

  // deliberately stubbing out getWinner behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public ReversiModel.PlayerType getWinner() {
    return null;
  }

  // deliberately stubbing out getCurrentPlayer behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public ReversiModel.PlayerType getCurrentPlayer() {
    return null;
  }

  // deliberately stubbing out getBoardSize behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public int getBoardSize() {
    return 0;
  }

  // deliberately stubbing out getCellContentsAt behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public Cell getCellContentsAt(int q, int r) {
    return null;
  }

  // deliberately stubbing out canThisCellBePlayedOn behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public boolean canThisCellBePlayedOn(Coordinate coord) {
    return false;
  }

  // deliberately stubbing out doesCurrentPlayerHaveAnyLegalMoves behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public boolean doesCurrentPlayerHaveAnyLegalMoves() {
    return false;
  }

  // deliberately stubbing out getCurrentPlayerScore behavior instead of implementing
  // because the strategy does not interact with this method
  @Override
  public int getCurrentPlayerScore(ReversiModel.PlayerType playerWhosScoreWeWant) {
    return 0;
  }
  

}
