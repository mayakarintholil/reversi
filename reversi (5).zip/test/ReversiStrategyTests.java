import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import model.Cell;
import model.Coordinate;
import model.IReversi;
import model.ReversiModel;
import strategies.CaptureMostOnThisTurn;
import strategies.ReversiStrategy;

/**
 * Tests for the strategy that returns the coordinate that captures the most disks on this turn
 * for the given player. These tests check whether the strategy returns the correct coordinates
 * for both players, at different points of the game, and in the case of ties.
 */
public class ReversiStrategyTests {

  //test the strategy didn't actually make a move in model (no mutation)
  // Build a collection of example games in known configurations, ask each strategy where
  // it would choose to move for a given player, and check that the result is as expected.
  ReversiStrategy strategy;
  IReversi model;

  @Before
  public void init() {
    model = new ReversiModel(5);
    strategy = new CaptureMostOnThisTurn();
  }

  @Test
  public void bestMoveForPlayer2InStartingConfigurationOfGame() {
    Assert.assertEquals(strategy.chooseMove(model, ReversiModel.PlayerType.PLAYER2),
            new Coordinate(1, 1));
  }

  @Test
  public void bestMoveForPlayer1IntermediatePointOfGame() {
    model.completeMove(model.getGameBoard().getCells()[1][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    // should be same as last one, player changes
    model.completeMove(model.getGameBoard().getCells()[1][1]);
    model.passMove();
    model.completeMove(model.getGameBoard().getCells()[1][4]);
    Assert.assertEquals(strategy.chooseMove(model, ReversiModel.PlayerType.PLAYER1),
            new Coordinate(2, 0));
  }

  @Test
  public void bestMoveForPlayer2IntermediatePointOfGame() {
    model.completeMove(model.getGameBoard().getCells()[1][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    // should be same as last one, player changes
    model.completeMove(model.getGameBoard().getCells()[1][1]);
    model.passMove();
    model.completeMove(model.getGameBoard().getCells()[1][4]);
    Assert.assertEquals(strategy.chooseMove(model, ReversiModel.PlayerType.PLAYER2),
            new Coordinate(2, 4));
  }


  //test that a tie in points actually returns the topmost leftmost coordinate
  @Test
  public void bestMoveForPlayer2IntermediatePointInCaseOfTies() {
    model.completeMove(model.getGameBoard().getCells()[1][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[2][3]);
    // should be same as last one, player changes
    model.completeMove(model.getGameBoard().getCells()[1][1]);
    model.passMove();
    model.completeMove(model.getGameBoard().getCells()[3][2]);
    Assert.assertEquals(strategy.chooseMove(model, ReversiModel.PlayerType.PLAYER1),
            new Coordinate(2, 1));
  }

  @Test
  public void bestMoveForPlayer1IntermediatePointInCaseOfTies() {
    model.completeMove(model.getGameBoard().getCells()[1][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    // should be same as last one, player changes
    model.completeMove(model.getGameBoard().getCells()[1][1]);
    model.passMove();
    model.completeMove(model.getGameBoard().getCells()[1][4]);
    Assert.assertEquals(strategy.chooseMove(model, ReversiModel.PlayerType.PLAYER2),
            new Coordinate(2, 0));
  }


  //test the strategy didn't actually make a move in model and mutate it
  @Test
  public void testStrategyDidNotMutateActualModelStartingConfigPlayer1() {
    IReversi model = new ReversiModel();
    strategy.chooseMove(model, ReversiModel.PlayerType.PLAYER1);
    Assert.assertEquals(model.getGameBoard().getCells()[1][1].getStateOfCell(),
            Cell.CellState.EMPTY);

  }

  @Test
  public void testStrategyDidNotMutateActualModelIntermediateGamePlayer2() {
    IReversi model = new ReversiModel();
    model.completeMove(model.getGameBoard().getCells()[1][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    strategy.chooseMove(model, ReversiModel.PlayerType.PLAYER2);
    Assert.assertEquals(model.getGameBoard().getCells()[3][0].getStateOfCell(),
            Cell.CellState.EMPTY); //ensures that even though strategy returns a coordinate to
    // capture most pieces, the main model does not make the move on that cell

  }


}