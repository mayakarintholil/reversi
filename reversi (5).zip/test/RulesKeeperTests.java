import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import model.Cell;
import model.Coordinate;
import model.HumanPlayer;
import model.Player;
import model.ReversiModel;
import model.RuleKeepers;

/**
 * represents our test class for the rule keeper class, in order to make sure
 * the rules are what we want them to be.
 */
public class RulesKeeperTests {
  RuleKeepers rulebook;
  ReversiModel model;
  Player player1;
  Player player2;
  Player player3;

  @Before
  public void initData() {
    rulebook = new RuleKeepers();
    model = new ReversiModel();
    player1 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER1);
    player2 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER2);
    player3 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER2);
  }

  @Test
  public void testNegInputForDimension() {
    Assert.assertThrows(IllegalArgumentException.class,
        () -> rulebook.cannotMakeBoardNegOrEvenInput(-1));
  }

  @Test
  public void testEvenInputForDimension() {
    Assert.assertThrows(IllegalArgumentException.class,
        () -> rulebook.cannotMakeBoardNegOrEvenInput(8));
  }

  @Test
  public void testChosenCellNotEmptyForMove() {
    Cell chosenCell = new Cell(Cell.CellState.BLACKFILLED, new Coordinate(2,2 ));
    Assert.assertThrows(IllegalArgumentException.class,
        () -> rulebook.chosenCellForMoveMustBeEmpty(chosenCell));
  }

  @Test
  public void testForOnlyTwoPlayers() {

    Assert.assertThrows(IllegalStateException.class,
        () -> rulebook.currentPlayerMustBePlayer1OrPlayer2(model, player1, player2));
  }

  @Test
  public void testCannotMoveAfterTwoPasses() {
    Assert.assertThrows(IllegalStateException.class,
        () -> rulebook.cannotMoveAfterTwoPasses(true));
  }
}
