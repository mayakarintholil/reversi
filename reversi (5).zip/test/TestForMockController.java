import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import model.IReversi;
import strategies.CaptureMostOnThisTurn;
import strategies.ReversiStrategy;
import view.ReversiFrame;
import view.ReversiView;

/**
 * Tests the mock controller that tests if moves have been visited. Also test for Mocking Players.
 */
public class TestForMockController {
  MockController mockController;
  IReversi model;
  ReversiView view;
  StringBuilder log;

  MockAIPlayer mockAIPlayer;

  ReversiStrategy strat;
  MockHumanPlayer mockHumanPlayer;

  @Before
  public void init() {
    log = new StringBuilder();
    mockController = new MockController(log);
  }

  @Before
  public void initPlayer() {
    log = new StringBuilder();
    view = new ReversiFrame(model);
    mockHumanPlayer = new MockHumanPlayer(log, view);
  }

  @Before
  public void initPlayerAI() {
    log = new StringBuilder();
    view = new ReversiFrame(model);
    strat = new CaptureMostOnThisTurn();
    mockAIPlayer = new MockAIPlayer(log, model, strat);
  }


  @Test
  public void testMockReturnsTranscript() {

    mockController.makeMove();
    mockController.makeMove();
    mockController.passOnTurn();
    mockController.makeMove();
    Assert.assertEquals(log.toString(), "A move has been madeA " +
            "move has been madeA player has " +
            "passedA move has been made");
  }

  @Test
  public void testMockHumanGetsMove() {

    mockHumanPlayer.getMeMyNextMove();
    Assert.assertEquals(log.toString(), "The next move is at"
            + view.getSelectedCellToMoveOn());
  }

  @Test
  public void testMockAIGetsMove() {
    mockAIPlayer.getMeMyNextMove();
    Assert.assertEquals(log.toString(), "The next move is at"
            + strat.chooseMove(model, model.getCurrentPlayer()));
  }

}
