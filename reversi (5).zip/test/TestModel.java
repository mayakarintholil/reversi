import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.awt.Color;

import model.Board;
import model.Cell;
import model.Coordinate;
import model.HumanPlayer;
import model.Player;
import model.IReversi;
import model.ReversiModel;

/**
 * Tests for this version of Reversi.
 */
public class TestModel {
  //testing the methods in our model

  Board board1;
  Board board2;
  Board smallBoard;

  Board board3;
  Board negBoard;
  Board evenBoard;
  Cell nonemptyCell;

  IReversi model;
  //make a board and check that the correct things are null

  @Before
  public void initData() {
    board1 = new Board(); //dimension of default 7
    board2 = new Board(5);
    board3 = new Board(9);
    model = new ReversiModel(5);
    //evenBoard = new Board(8);
    // negBoard = new Board(-1);
    nonemptyCell = new Cell(Cell.CellState.BLACKFILLED, new Coordinate(2, 2));
    smallBoard = new Board(3);

  }

  //BOARD CLASS TESTS
  @Test
  public void tryMakingBogusBoard() {
    Assert.assertThrows("Cannot have invalid input for boardsize. Please try again " +
                    "with a new dimension", IllegalArgumentException.class,
        () -> evenBoard.getCells());
  }

  @Test
  public void tryMakingNegBoard() {
    Assert.assertThrows("cannot make board", IllegalArgumentException.class,
        () -> negBoard.getCells());
  }

  @Test
  public void testMoveOnANonEmptyCell() {
    Assert.assertThrows("cannot move on an already filled cell",
            IllegalArgumentException.class,
        () -> model.completeMove(model.getGameBoard().getCells()[3][1]));
  }

  //fill my cell
  @Test
  public void testFillMyCellFilledAlready() {
    Cell nonemptyCell = new Cell(Cell.CellState.BLACKFILLED, new Coordinate(2, 2));
    Assert.assertThrows(IllegalStateException.class, () -> nonemptyCell.fillMyCell(Color.black));
  }

  @Test
  public void testFillMyCellWhite() {
    Cell emptyCell = new Cell(Cell.CellState.EMPTY, new Coordinate(2, 2));
    emptyCell.fillMyCell(Color.WHITE);
    Assert.assertEquals(emptyCell.getStateOfCell(), Cell.CellState.WHITEFILLED);
  }

  @Test
  public void testFillMyCellBlack() {
    Cell emptyCell = new Cell(Cell.CellState.EMPTY, new Coordinate(2, 2));
    emptyCell.fillMyCell(Color.BLACK);
    Assert.assertEquals(emptyCell.getStateOfCell(), Cell.CellState.BLACKFILLED);
  }

  // flip my color
  @Test
  public void testFlipEmpty() {
    Cell emptyCell = new Cell(Cell.CellState.EMPTY, new Coordinate(2, 2));
    Assert.assertThrows(IllegalStateException.class, () -> emptyCell.flipMyColor());
  }

  @Test
  public void testFlipWhite() {
    Cell blackCell = new Cell(Cell.CellState.BLACKFILLED, new Coordinate(2, 2));
    blackCell.flipMyColor();
    Assert.assertEquals(blackCell.getStateOfCell(), Cell.CellState.WHITEFILLED);
  }

  @Test
  public void testFlipBlack() {
    Cell whiteCell = new Cell(Cell.CellState.WHITEFILLED, new Coordinate(2, 2));
    whiteCell.flipMyColor();
    Assert.assertEquals(whiteCell.getStateOfCell(), Cell.CellState.BLACKFILLED);
  }

  @Test
  public void testGameOver() {
    Assert.assertFalse(model.isGameOver());
  }

  @Test
  public void testGameInMiddleFalse() {
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    model.completeMove(model.getGameBoard().getCells()[1][1]);
    model.passMove();
    model.completeMove(model.getGameBoard().getCells()[1][4]);
    Assert.assertFalse(model.isGameOver());
  }

  @Test
  public void testGameOverTwoPlayerPassRandomly() {
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.passMove();
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    model.passMove();
    model.completeMove(model.getGameBoard().getCells()[1][4]);
    Assert.assertFalse(model.isGameOver());
  }

  @Test
  public void testGameOverTwoPlayerPassInARow() {
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    model.completeMove(model.getGameBoard().getCells()[1][1]);
    model.passMove();
    model.passMove();
    Assert.assertTrue(model.isGameOver());
  }

  @Test
  public void testGameOverTwoPlayerPassInARowThenTryMove() {
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    model.completeMove(model.getGameBoard().getCells()[1][1]);
    model.passMove();
    model.passMove();
    Assert.assertThrows("cannot play after game is over", IllegalStateException.class, () ->
            model.completeMove(model.getGameBoard().getCells()[4][2]));
  }

  @Test
  public void testGameOverWhenNoMovesLeft() {
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    model.completeMove(model.getGameBoard().getCells()[1][1]);
    model.completeMove(model.getGameBoard().getCells()[1][4]);
    model.completeMove(model.getGameBoard().getCells()[0][3]);
    Assert.assertTrue(model.isGameOver());

  }


  //test game over with two players passing
  // tests game over with no more moves/ all filled


  @Test
  public void LegalConstructionOfBoard() {
    Assert.assertEquals(board1.getCells().length, 7);
  }

  @Test
  public void LegalConstructionOfBoard2() {
    Assert.assertEquals(board3.getCells().length, 9);
  }

  @Test
  public void IllegalConstructionOfBoard() {
    try {
      board1 = new Board(4);
    } catch (IllegalArgumentException exception) {
      Assert.assertThrows(IllegalArgumentException.class, () -> board1.getCells());
    }
  }

  @Test
  public void testRightValsAreNull() {
    // want to check that the first cell is null
    Assert.assertNull(board2.getCells()[0][0]);
    Assert.assertNull(board2.getCells()[1][0]);
    Assert.assertNotNull(board2.getCells()[2][0]);
    Assert.assertNotNull(board2.getCells()[3][0]);
    Assert.assertNotNull(board2.getCells()[4][0]);
    Assert.assertNull(board2.getCells()[0][1]);
    Assert.assertNotNull(board2.getCells()[1][1]);
    Assert.assertNotNull(board2.getCells()[0][2]);


    Assert.assertNull(board2.getCells()[4][3]);
    Assert.assertNull(board2.getCells()[4][4]);
    Assert.assertNull(board2.getCells()[3][4]);

    Assert.assertNotNull(board2.getCells()[4][2]);
    Assert.assertNotNull(board2.getCells()[3][3]);
    Assert.assertNotNull(board2.getCells()[2][4]);

    //for seven board
    //true
    Assert.assertNull(board1.getCells()[0][0]);
    Assert.assertNull(board1.getCells()[1][0]);
    Assert.assertNull(board1.getCells()[2][0]);
    Assert.assertNull(board1.getCells()[0][1]);
    Assert.assertNull(board1.getCells()[1][1]);
    Assert.assertNull(board1.getCells()[0][2]);
    Assert.assertNull(board1.getCells()[6][4]);
    Assert.assertNull(board1.getCells()[6][5]);
    Assert.assertNull(board1.getCells()[6][6]);
    Assert.assertNull(board1.getCells()[5][5]);
    Assert.assertNull(board1.getCells()[5][6]);
    Assert.assertNull(board1.getCells()[4][6]);
  }

  //doesCellHaveTwoNeighborsTopRight(Cell chosencell)

  //TOP RIGHT
  //@Test
  //public void testHaveTwoNeighborsTopRight() {
  //    capture null
  //   Assert.assertTrue(model.doesCellHaveTwoNeighborsTopRight
  //    (model.getGameBoard().getCells()[2][3]));
  //}
  //  @Test
  //  public void testHaveTwoNeighborsTopRightFalse() {
  //    //capture null
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsTopRight(
  //    model.getGameBoard().getCells()[4][0]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsTopRightWithOneNeighbor() {
  //    //capture null
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsTopRight(
  //    model.getGameBoard().getCells()[2][1]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsTopRightNullCell() {
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsTopRight(
  //    model.getGameBoard().getCells()[0][0]));
  //  }
  //
  //  @Test
  //  //STRAIGHT RIGHT
  //  public void testHaveTwoNeighborsStraightRight() {
  //    //capture null
  //   // Assert.assertTrue(model.doesCellHaveTwoNeighborsStraightRight(
  //   model.getGameBoard().getCells()[2][2]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsStraightRightFalse() {
  //    //capture null
  //   // Assert.assertFalse(model.doesCellHaveTwoNeighborsStraightRight(
  //   model.getGameBoard().getCells()[4][0]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsStraightRightWithOneNeighbor() {
  //    //capture null
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsStraightRight(
  //    model.getGameBoard().getCells()[3][2]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsStraightRightNullCell() {
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsStraightRight(
  //    model.getGameBoard().getCells()[0][0]));
  //  }
  //
  //  //BOTTOM RIGHT
  //  @Test
  //  public void testHaveTwoNeighborsBottomRight() {
  //    //capture null
  //    //Assert.assertTrue(model.doesCellHaveTwoNeighborsBottomRight(
  //    model.getGameBoard().getCells()[2][2]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsBottomRightFalse() {
  //    //capture null
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsBottomRight(
  //    model.getGameBoard().getCells()[4][2]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsBottomRightWithOneNeighbor() {
  //    //capture null
  //   // Assert.assertFalse(model.doesCellHaveTwoNeighborsBottomRight(
  //   model.getGameBoard().getCells()[3][2]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsBottomRightNullCell() {
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsBottomRight(
  //    model.getGameBoard().getCells()[0][0]));
  //  }
  //
  //  //BOTTOM LEFT
  //  @Test
  //  public void testHaveTwoNeighborsBottomLeft() {
  //    //capture null
  //    //Assert.assertTrue(model.doesCellHaveTwoNeighborsBottomLeft(
  //    model.getGameBoard().getCells()[2][2]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsBottomLeftFalse() {
  //    //capture null
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsBottomLeft(
  //    model.getGameBoard().getCells()[0][3]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsBottomLeftWithOneNeighbor() {
  //    //capture null
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsBottomLeft(
  //    model.getGameBoard().getCells()[1][3]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsBottomLeftNullCell() {
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsBottomLeft(
  //    model.getGameBoard().getCells()[0][0]));
  //  }
  //
  //  //STRAIGHT LEFT
  //  @Test
  //  public void testHaveTwoNeighborsStraightLeft() {
  //    //capture null
  //    //Assert.assertTrue(model.doesCellHaveTwoNeighborsStraightLeft(
  //    model.getGameBoard().getCells()[2][2]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsStraightLeftFalse() {
  //    //capture null
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsStraightLeft(
  //    model.getGameBoard().getCells()[0][3]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsStraightLeftWithOneNeighbor() {
  //    //capture null
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsStraightLeft(
  //    model.getGameBoard().getCells()[1][3]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsStraightLeftNullCell() {
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsStraightLeft(
  //    model.getGameBoard().getCells()[0][0]));
  //  }
  //
  //  //TEST TOP LEFT
  //  @Test
  //  public void testHaveTwoNeighborsTopLeft() {
  //    //capture null
  //    //Assert.assertTrue(model.doesCellHaveTwoNeighborsTopLeft(
  //    model.getGameBoard().getCells()[2][2]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsTopLeftFalse() {
  //    //capture null
  //   // Assert.assertFalse(model.doesCellHaveTwoNeighborsTopLeft(
  //   model.getGameBoard().getCells()[1][1]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsTopLeftWithOneNeighbor() {
  //    //capture null
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighborsTopLeft(
  //    model.getGameBoard().getCells()[0][3]));
  //  }
  //
  //  @Test
  //  public void testHaveTwoNeighborsTopLeftNullCell() {
  //    //Assert.assertFalse(model.doesCellHaveTwoNeighbors
  //    TopLeft(model.getGameBoard().getCells()[0][0]));
  //  }
  //
  //
  //  @Test
  //  public void testCellExistsInBoard() {
  //    //Assert.assertTrue(model.cellExistsInBoard(model.getGameBoard().getCells(),
  //    // model.getGameBoard().getCells()[2][2]));
  //  }
  //
  //  @Test
  //  public void testCellExistsInBoard2() {
  //    //Assert.assertTrue(model.cellExistsInBoard(model.getGameBoard().getCells(),
  //    // model.getGameBoard().getCells()[3][1]));
  //  }
  //
  //  @Test
  //  public void testCellExistsInBoard3() {
  //    //Assert.assertTrue(model.cellExistsInBoard(model.getGameBoard().getCells(),
  //    //model.getGameBoard().getCells()[4][0]));
  //  }
  //
  //
  //
  //  //are all cells filled - change method to PRIVATE AFTER
  //  @Test
  //  public void areAllCellsFilledForANotFullBoard() {
  //    //Assert.assertFalse(model.areAllCellsFilled());
  //
  //    //try and example with a full board? how to fill manually
  //
  //  }

  @Test
  public void testSwitchPlayers() {
    IReversi model = new ReversiModel(9);
    Player player1 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER1);
    Player player2 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER2);

    if (model.getCurrentPlayer().equals(player1)) {
      model.passMove();
      Assert.assertEquals(model.getCurrentPlayer(), player2);
    }
  }

  @Test
  public void testPassMoves() {
    IReversi model = new ReversiModel(9);
    Player player1 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER1);
    Player player2 = new HumanPlayer(model, ReversiModel.PlayerType.PLAYER2);

    if (model.getCurrentPlayer().equals(player1)) {
      model.passMove();
      Assert.assertEquals(model.getCurrentPlayer(), player2);
    }
  }


  @Test
  public void testGetWinner() {
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.passMove();
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    // should be same as last one, player changes
    model.passMove();
    System.out.println(model.getWinner());
    model.passMove(); // rig the right player
    Assert.assertEquals(model.getWinner(), model.getCurrentPlayer());
  }

  @Test
  public void testGetWinnerGameOver() {
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    model.completeMove(model.getGameBoard().getCells()[1][1]);

    model.completeMove(model.getGameBoard().getCells()[1][4]);

    model.completeMove(model.getGameBoard().getCells()[0][3]);
    Assert.assertTrue(model.isGameOver());
    Assert.assertEquals(model.getWinner(), model.getCurrentPlayer());
  }


  //test complete move

  //shouldn't fill a cell if it has no legal paths for move
  @Test
  public void testNoMoveIsMadeWhenThereAreNoValidPaths() {
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[0][2]);
    Assert.assertEquals(model.getGameBoard().getCells()[0][2].getStateOfCell(),
            Cell.CellState.EMPTY);

  }

  //try to make a move on one that is already filled
  @Test
  public void testMoveOnAlreadyFullCell() {
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    // should be same as last one, player changes
    model.completeMove(model.getGameBoard().getCells()[1][1]);

    model.completeMove(model.getGameBoard().getCells()[1][4]);

    model.completeMove(model.getGameBoard().getCells()[0][3]);

    Assert.assertThrows("cannot move on an already filled cell", IllegalArgumentException.class,
        () -> model.completeMove(model.getGameBoard().getCells()[0][3]));
  }

  // try to make a move that is legal
  @Test
  public void testMoveLegalBlack() {
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    Assert.assertEquals(model.getGameBoard().getCells()[3][3].getStateOfCell(),
            Cell.CellState.BLACKFILLED);
  }

  @Test
  public void testMoveLegalWhite() {
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    Assert.assertEquals(model.getGameBoard().getCells()[4][1].getStateOfCell(),
            Cell.CellState.WHITEFILLED);
  }

  //test for getCellContentsAt
  @Test
  public void testGetCellContentsValidCell() {
    Assert.assertEquals(model.getCellContentsAt(2,2),
            new Cell(model.getGameBoard().getCells()[2][2].getStateOfCell(), new Coordinate(2,
                    2)));
  }

  @Test
  public void testGetCellContentsNull() {
    Assert.assertThrows("Null cells don't have contents.", IllegalArgumentException.class,
        () -> model.getCellContentsAt(0,0));
  }

  @Test
  public void testGetCellContentsOutOfBounds() {
    Assert.assertThrows("Can't get contents of a cell out of bounds.",
            IllegalArgumentException.class, () -> model.getCellContentsAt(7,4));
  }


  //tests for canThisCellBePlayedOn
  @Test
  public void testCanNullCellBePlayedOn() {
    Assert.assertFalse(model.canThisCellBePlayedOn(new Coordinate(0,0)));
  }

  @Test
  public void testCanValidCellBePlayedOn() {
    IReversi model = new ReversiModel(5);
    Assert.assertTrue(model.canThisCellBePlayedOn(new Coordinate(3,0)));
  }

  @Test
  public void testCanOutOfBoundsCellBePlayedOn() {
    Assert.assertFalse(model.canThisCellBePlayedOn(new Coordinate(7,3)));
  }

  //tests for doesCurrentPlayerHaveAnyLegalMoves

  @Test
  public void testStartingGameHaveAnyLegalMoves() {
    IReversi model = new ReversiModel(5);
    Assert.assertTrue(model.doesCurrentPlayerHaveAnyLegalMoves());
  }

  @Test
  public void testOHaveAnyLegalMovesNoMoreMoves() {
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    model.completeMove(model.getGameBoard().getCells()[1][1]);
    model.passMove();
    model.completeMove(model.getGameBoard().getCells()[1][4]);

    //now O's turn
    Assert.assertFalse(model.doesCurrentPlayerHaveAnyLegalMoves());
  }


  @Test
  public void testGetScoreStartingGame() {
    IReversi model = new ReversiModel(5);
    Assert.assertEquals(model.getCurrentPlayerScore(ReversiModel.PlayerType.PLAYER1), 3);
  }

  @Test
  public void testGetScoreMidGame() {
    IReversi model = new ReversiModel(5);
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    // should be same as last one, player changes
    model.completeMove(model.getGameBoard().getCells()[1][1]);
    model.passMove();
    model.completeMove(model.getGameBoard().getCells()[1][4]);
    //now O's turn
    Assert.assertEquals(model.getCurrentPlayerScore(ReversiModel.PlayerType.PLAYER2), 1);

  }

}