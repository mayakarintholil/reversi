import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import model.Cell;
import model.IReversi;
import model.ReversiModel;
import strategies.CaptureMostOnThisTurn;
import strategies.ReversiStrategy;

/**
 * Tests for MockReversiModel to ensure that the correct log is appeneded and returned, where
 * every cell that is empty is visited by the strategy.
 */
public class TestWithMock {

  //test the strategy didn't actually make a move in model (no mutation)

  ReversiStrategy strategy;
  IReversi model;
  IReversi bogusModel;

  StringBuilder log;

  @Before
  public void init() {
    log = new StringBuilder();
    model = new MockReversiModel(log);
    strategy = new CaptureMostOnThisTurn();
    bogusModel = new MockBogusReversiModel();

  }

  @Test
  public void testMockReturnsTranscript() {

    strategy.chooseMove(model,
            ReversiModel.PlayerType.PLAYER1);
    Assert.assertEquals(log.toString(), "");
  }

  @Test
  public void testIllegalMoveWorksGivenBogusModel() {
    strategy.chooseMove(model, ReversiModel.PlayerType.PLAYER1);
    // test that given bogus coord, it does make the move
    model.completeMove(model.getGameBoard().getCells()[1][0]);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    strategy.chooseMove(model, ReversiModel.PlayerType.PLAYER2);
    Assert.assertEquals(model.getGameBoard().getCells()[3][0].getStateOfCell(),
            Cell.CellState.BLACKFILLED);
  }
}