import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import model.IReversi;
import model.ReversiModel;
import view.ReversiTextView;
import view.TextView;

/**
 * Class to test TextView and see the game being played.
 */
public class TextViewTest {
  IReversi model;
  //make a board and check that the correct things are null

  @Before
  public void initData() {
    model = new ReversiModel(5);

  }

  @Test
  public void testViewGame() {
    TextView viewGame = new ReversiTextView(model);
    Assert.assertEquals("_ _ _\n" +
                    " _ O X _\n" +
                    "_ _ _ _ _\n" +
                    " _ _ _ _\n" +
                    "  _ O _",
            viewGame.toString());
  }

  @Test
  public void testViewGame2() {
    TextView viewGame = new ReversiTextView(model);
    System.out.println(viewGame);
    Assert.assertEquals(viewGame.toString(), "   _ _ _\n" +
            "  _ O X _\n" +
            " _ X _ O _\n" +
            "  _ O X _ \n" +
            "   _ _ _  ");
  }

  @Test
  public void testViewGameAfterMultipleMove() {

    TextView viewGame = new ReversiTextView(model);
    System.out.println(viewGame);
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    System.out.println(viewGame);

    model.completeMove(model.getGameBoard().getCells()[4][1]);
    System.out.println(viewGame);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    System.out.println(viewGame);
    // should be same as last one, player changes


    model.completeMove(model.getGameBoard().getCells()[1][1]);
    System.out.println(viewGame);
    model.passMove();
    System.out.println(viewGame);

    model.completeMove(model.getGameBoard().getCells()[1][4]);
    System.out.println(viewGame);

    Assert.assertEquals(viewGame.toString(), "   _ _ _\n" +
            "  _ O X _\n" +
            " _ X _ O _\n" +
            "  _ O X _ \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  _ O O _\n" +
            " _ X _ O _\n" +
            "  _ O X _ \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  _ O O X\n" +
            " _ X _ X _\n" +
            "  _ O X _ \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  _ O O X\n" +
            " _ X _ O _\n" +
            "  _ O O O \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  X X X X\n" +
            " _ X _ O _\n" +
            "  _ O O O \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  X X X X\n" +
            " _ X _ O _\n" +
            "  _ O O O \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  X X X X\n" +
            " _ X _ X _\n" +
            "  _ O X O \n" +
            "   _ X _ ");

  }

  @Test
  public void testViewGameAfterTwoPassesNotConsec() {
    TextView viewGame = new ReversiTextView(model);
    System.out.println(viewGame);
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    System.out.println(viewGame);
    model.passMove();
    System.out.println(viewGame);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    System.out.println(viewGame);
    // should be same as last one, player changes
    model.passMove();
    System.out.println(viewGame);
    Assert.assertEquals(viewGame.toString(), "\n" +
            "   _ _ _\n" +
            "  _ O X _\n" +
            " _ X _ O _\n" +
            "  _ O X _ \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  _ O O _\n" +
            " _ X _ O _\n" +
            "  _ O X _ \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  _ O O _\n" +
            " _ X _ O _\n" +
            "  _ O X _ \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  _ O O _\n" +
            " _ X _ O _\n" +
            "  _ O O O \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  _ O O _\n" +
            " _ X _ O _\n" +
            "  _ O O O \n" +
            "   _ _ _  \n");
  }

  @Test
  public void testViewGameAfterTwoPassesConsec() {
    TextView viewGame = new ReversiTextView(model);
    System.out.println(viewGame);
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    System.out.println(viewGame);
    model.passMove();
    // should be same as last one, player changes
    model.passMove();
    System.out.println(viewGame);
    Assert.assertEquals(viewGame.toString(), " _ _ _\n" +
            "  _ O X _\n" +
            " _ X _ O _\n" +
            "  _ O X _ \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  _ O O _\n" +
            " _ X _ O _\n" +
            "  _ O X _ \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  _ O O _\n" +
            " _ X _ O _\n" +
            "  _ O X _ \n" +
            "   _ _ _  \n" +
            " GAME OVER!!!!!!!!!!!!!!!!");
  }

  @Test
  public void testViewGameThrowWhenPlayingOnAlreadyTakenCell() {
    TextView viewGame = new ReversiTextView(model);
    System.out.println(viewGame);
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    System.out.println(viewGame);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    System.out.println(viewGame);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    System.out.println(viewGame);
    // should be same as last one, player changes


    model.completeMove(model.getGameBoard().getCells()[1][1]);
    System.out.println(viewGame);

    model.completeMove(model.getGameBoard().getCells()[1][4]);
    System.out.println(viewGame);

    model.completeMove(model.getGameBoard().getCells()[0][3]);
    System.out.println(viewGame);

    model.completeMove(model.getGameBoard().getCells()[0][3]);
    System.out.println(viewGame);
    Assert.assertThrows(IllegalArgumentException.class, () -> viewGame.toString());
  }

  @Test
  //when no valid moves are left game should be over
  public void testViewGameFinishGame() {
    TextView viewGame = new ReversiTextView(model);
    System.out.println(viewGame);
    model.completeMove(model.getGameBoard().getCells()[3][0]);
    System.out.println(viewGame);
    model.completeMove(model.getGameBoard().getCells()[4][1]);
    System.out.println(viewGame);
    model.completeMove(model.getGameBoard().getCells()[3][3]);
    System.out.println(viewGame);
    // should be same as last one, player changes


    model.completeMove(model.getGameBoard().getCells()[1][1]);
    System.out.println(viewGame);

    model.completeMove(model.getGameBoard().getCells()[1][4]);
    System.out.println(viewGame);

    model.completeMove(model.getGameBoard().getCells()[0][3]);
    System.out.println(viewGame);
    Assert.assertEquals(viewGame.toString(), " _ _ _\n" +
            "  _ O X _\n" +
            " _ X _ O _\n" +
            "  _ O X _ \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  _ O O _\n" +
            " _ X _ O _\n" +
            "  _ O X _ \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  _ O O X\n" +
            " _ X _ X _\n" +
            "  _ O X _ \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  _ O O X\n" +
            " _ X _ O _\n" +
            "  _ O O O \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  X X X X\n" +
            " _ X _ O _\n" +
            "  _ O O O \n" +
            "   _ _ _  \n" +
            "\n" +
            "   _ O _\n" +
            "  X X X X\n" +
            " _ X _ O _\n" +
            "  _ O O O \n" +
            "   _ O _  \n" +
            "\n" +
            "   _ O _\n" +
            "  X X X X\n" +
            " _ X _ O _\n" +
            "  X O O O \n" +
            "   _ O _  \n" +
            " GAME OVER!!!!!!!!!!!!!!!!");

  }


}
